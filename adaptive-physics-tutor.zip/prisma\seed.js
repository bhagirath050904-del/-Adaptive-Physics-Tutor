const { PrismaClient } = require("@prisma/client");
const fs = require("fs");
const path = require("path");

const prisma = new PrismaClient();

async function main() {
  console.log("Seeding database with default student and concept masteries...");

  const conceptsPath = path.join(__dirname, "../data/concepts.json");
  const concepts = JSON.parse(fs.readFileSync(conceptsPath, "utf-8"));

  // Ensure default student exists
  const student = await prisma.student.upsert({
    where: { id: "demo-student" },
    update: {},
    create: {
      id: "demo-student",
      name: "Aarav Sharma (Class 10 CBSE)",
    },
  });

  console.log(`Student created/verified: ${student.name} (${student.id})`);

  // Initialize concept masteries with prior P(L0) = 0.20
  for (const c of concepts) {
    await prisma.conceptMastery.upsert({
      where: {
        studentId_conceptId: {
          studentId: student.id,
          conceptId: c.id,
        },
      },
      update: {},
      create: {
        studentId: student.id,
        conceptId: c.id,
        mastery: 0.20,
        attemptsCount: 0,
        correctCount: 0,
      },
    });
  }

  console.log(`Initialized ${concepts.length} concept masteries at prior P(L0) = 0.20`);
}

main()
  .catch((e) => {
    console.error("Seed error:", e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
