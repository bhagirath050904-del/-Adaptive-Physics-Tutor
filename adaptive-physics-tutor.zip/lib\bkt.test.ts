import { describe, it, expect } from "vitest";
import {
  calculatePosterior,
  updateMastery,
  propagateToPrerequisites,
  DEFAULT_BKT_PARAMS,
  clampProbability,
} from "./bkt";

describe("Bayesian Knowledge Tracing (BKT) Engine", () => {
  it("should clamp probabilities within valid numerical bounds [0.01, 0.99]", () => {
    expect(clampProbability(-0.5)).toBe(0.01);
    expect(clampProbability(1.5)).toBe(0.99);
    expect(clampProbability(0.45678)).toBe(0.4568);
  });

  it("should increase concept mastery on a correct answer", () => {
    const prior = 0.20;
    const result = updateMastery(prior, true, DEFAULT_BKT_PARAMS);

    // Posterior = (0.2 * 0.9) / (0.2 * 0.9 + 0.8 * 0.2) = 0.18 / (0.18 + 0.16) = 0.18 / 0.34 = ~0.5294
    // Transition = 0.5294 + (1 - 0.5294) * 0.15 = ~0.6000
    expect(result.posterior).toBeGreaterThan(prior);
    expect(result.updatedMastery).toBeGreaterThan(prior);
    expect(result.delta).toBeGreaterThan(0);
    expect(result.updatedMastery).toBeCloseTo(0.60, 2);
  });

  it("should decrease concept mastery on an incorrect answer", () => {
    const prior = 0.60;
    const result = updateMastery(prior, false, DEFAULT_BKT_PARAMS);

    expect(result.updatedMastery).toBeLessThan(prior);
    expect(result.delta).toBeLessThan(0);
  });

  it("should propagate attenuated positive update to prerequisite concepts", () => {
    const targetDelta = 0.40;
    const prerequisites = {
      c2_electric_current: 0.30,
      c3_potential_diff: 0.25,
    };

    const updates = propagateToPrerequisites(targetDelta, prerequisites, DEFAULT_BKT_PARAMS);

    // Attenuation factor is 0.35 => delta_p = 0.40 * 0.35 = 0.14
    expect(updates.c2_electric_current.updatedMastery).toBeCloseTo(0.30 + 0.14, 2);
    expect(updates.c3_potential_diff.updatedMastery).toBeCloseTo(0.25 + 0.14, 2);
    expect(updates.c2_electric_current.delta).toBeCloseTo(0.14, 2);
  });

  it("should propagate attenuated negative update to prerequisites on wrong answer", () => {
    const targetDelta = -0.20;
    const prerequisites = {
      c2_electric_current: 0.50,
    };

    const updates = propagateToPrerequisites(targetDelta, prerequisites, DEFAULT_BKT_PARAMS);
    // Attenuation is 0.35 => delta_p = -0.20 * 0.35 = -0.07
    expect(updates.c2_electric_current.updatedMastery).toBeCloseTo(0.50 - 0.07, 2);
    expect(updates.c2_electric_current.delta).toBeCloseTo(-0.07, 2);
  });

  it("should converge towards 0.99 with continuous correct answers", () => {
    let mastery = 0.10;
    for (let i = 0; i < 6; i++) {
      const res = updateMastery(mastery, true);
      mastery = res.updatedMastery;
    }
    expect(mastery).toBeGreaterThanOrEqual(0.95);
  });

  it("should maintain strictly monotonic posterior with respect to prior", () => {
    const lowPriorPosterior = calculatePosterior(0.2, true);
    const highPriorPosterior = calculatePosterior(0.7, true);
    expect(highPriorPosterior).toBeGreaterThan(lowPriorPosterior);
  });
});
