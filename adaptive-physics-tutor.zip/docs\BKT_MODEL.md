# Bayesian Knowledge Tracing (BKT) Learner Model

## 1. Introduction
The learner model in Adaptive Physics Tutor uses standard **Bayesian Knowledge Tracing (BKT)** to track the latent probability that a student understands a specific physics concept.

Crucially:
- **Zero LLM involvement** in the score calculation: the updates are 100% deterministic, auditable, and reproducible.
- **Prerequisite Propagation:** Whenever a concept's mastery changes, an attenuated update is passed upstream to its foundational prerequisite concepts.

---

## 2. Standard BKT Parameters

| Parameter | Symbol | Default Value | Description |
| :--- | :--- | :--- | :--- |
| **Prior** | $P(L_0)$ | `0.20` | Probability that a student already knows the concept before any practice. |
| **Transition** | $P(T)$ | `0.15` | Probability of learning/acquiring the concept at a given practice opportunity. |
| **Guess** | $P(G)$ | `0.20` | Probability of answering correctly despite not knowing the concept (4-option MCQ). |
| **Slip** | $P(S)$ | `0.10` | Probability of answering incorrectly despite knowing the concept. |
| **Attenuation** | $\alpha$ | `0.35` | Fractional factor of mastery change propagated to direct prerequisite concepts. |

---

## 3. Mathematical Update Formulation

### Step 1: Posterior Observation Update
Given prior belief $P(L_{t-1})$ and observation $y_t \in \{0, 1\}$ ($1$ = correct, $0$ = incorrect):

#### Case A: Correct Response ($y_t = 1$)
$$P(L_t \mid y_t = 1) = \frac{P(L_{t-1}) \cdot (1 - P(S))}{P(L_{t-1}) \cdot (1 - P(S)) + (1 - P(L_{t-1})) \cdot P(G)}$$

*Example with default values and $P(L_{t-1}) = 0.20$:*
- Numerator $= 0.20 \times (1 - 0.10) = 0.18$
- Denominator $= 0.18 + (1 - 0.20) \times 0.20 = 0.18 + 0.16 = 0.34$
- $P(L_t \mid y_t = 1) = \frac{0.18}{0.34} \approx 0.5294$

#### Case B: Incorrect Response ($y_t = 0$)
$$P(L_t \mid y_t = 0) = \frac{P(L_{t-1}) \cdot P(S)}{P(L_{t-1}) \cdot P(S) + (1 - P(L_{t-1})) \cdot (1 - P(G))}$$

*Example with default values and $P(L_{t-1}) = 0.60$:*
- Numerator $= 0.60 \times 0.10 = 0.06$
- Denominator $= 0.06 + (1 - 0.60) \times (1 - 0.20) = 0.06 + 0.32 = 0.38$
- $P(L_t \mid y_t = 0) = \frac{0.06}{0.38} \approx 0.1579$

---

### Step 2: Knowledge Transition (Learning Step)
Following observation, the student undergoes a practice opportunity where knowledge acquisition may occur:
$$P(L_{t+1}) = P(L_t \mid y_t) + (1 - P(L_t \mid y_t)) \cdot P(T)$$

*Continuing Case A ($P(L_t \mid y_t = 1) \approx 0.5294$):*
- $P(L_{t+1}) = 0.5294 + (1 - 0.5294) \times 0.15 = 0.5294 + 0.0706 = \mathbf{0.6000}$
- $\Delta = P(L_{t+1}) - P(L_{t-1}) = 0.6000 - 0.2000 = \mathbf{+0.4000}$

All probabilities are clamped to $[0.01, 0.99]$ to prevent numerical degradation.

---

### Step 3: Upstream Prerequisite Propagation
A student solving a composite problem (e.g., Ohm's Law $V = IR$) also demonstrates or fails to demonstrate understanding of its foundational prerequisites (Electric Current and Potential Difference).

For target concept $C$ with change $\Delta = P(L_{t+1}) - P(L_{t-1})$, for each direct prerequisite $P \in \text{prerequisites}(C)$:
$$\Delta_P = \alpha \cdot \Delta$$
$$P_{\text{new}}(P) = \text{clamp}(P(P) + \Delta_P, 0.01, 0.99)$$

*Continuing Case A ($\Delta = +0.4000, \alpha = 0.35$):*
- $\Delta_P = 0.35 \times 0.4000 = \mathbf{+0.1400}$
- For prerequisite with initial mastery $0.2000$: $P_{\text{new}}(P) = 0.2000 + 0.1400 = \mathbf{0.3400}$

---

## 4. Visual Mastery Thresholds

The UI maps the continuous probability $P(L)$ into three clear visual cognitive states:

| Range | Status | Node Border & Badge | Hex Color |
| :--- | :--- | :--- | :--- |
| **$P(L) < 0.40$** | **Developing** | Rose / Red | `#ef4444` |
| **$0.40 \le P(L) < 0.70$** | **Progressing** | Amber / Orange | `#f59e0b` |
| **$P(L) \ge 0.70$** | **Mastered** | Emerald / Green | `#10b981` |

---

## 5. Verification & Unit Tests
The deterministic engine is fully verified via automated Vitest test suites (`lib/bkt.test.ts`):
1. **Bound Clamping:** Enforces strict $[0.01, 0.99]$ numerical bounds.
2. **Correctness Reward:** Strictly increases mastery upon a correct response.
3. **Error Penalty:** Strictly decreases mastery upon an incorrect response.
4. **Prerequisite Propagation:** Attenuated positive updates for prerequisites on correct answers; attenuated negative updates on errors.
5. **Convergence:** Monotonically approaches $0.99$ upon repeated correct answers.
6. **Strict Monotonicity:** Higher prior always yields higher posterior.
