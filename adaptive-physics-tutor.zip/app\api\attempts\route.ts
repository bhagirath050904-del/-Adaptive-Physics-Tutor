import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import conceptsData from "@/data/concepts.json";
import questionsData from "@/data/questions.json";
import { updateMastery, propagateToPrerequisites, DEFAULT_BKT_PARAMS } from "@/lib/bkt";
import { detectMisconception } from "@/lib/llm";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const {
      studentId = "demo-student",
      questionId,
      conceptId,
      selectedOptionId,
      studentReason = "",
    } = body;

    if (!questionId || !conceptId || !selectedOptionId) {
      return NextResponse.json(
        { success: false, error: "Missing required fields" },
        { status: 400 }
      );
    }

    // 1. Locate Question & Concept
    const question = questionsData.find((q) => q.id === questionId);
    if (!question) {
      return NextResponse.json(
        { success: false, error: "Question not found" },
        { status: 404 }
      );
    }

    const conceptMeta = conceptsData.find((c) => c.id === conceptId);
    if (!conceptMeta) {
      return NextResponse.json(
        { success: false, error: "Concept not found in ontology" },
        { status: 404 }
      );
    }

    const isCorrect = question.correctOptionId === selectedOptionId;

    // 2. Fetch current mastery for target concept
    let currentMasteryRecord = await prisma.conceptMastery.findUnique({
      where: {
        studentId_conceptId: {
          studentId,
          conceptId,
        },
      },
    });

    const priorMastery = currentMasteryRecord ? currentMasteryRecord.mastery : DEFAULT_BKT_PARAMS.pL0;

    // 3. Deterministic BKT Update for target concept
    const bktResult = updateMastery(priorMastery, isCorrect, DEFAULT_BKT_PARAMS);

    // 4. Prerequisite Attenuated Update
    const directPrerequisites = conceptMeta.prerequisites || [];
    let prereqMasteries: Record<string, number> = {};

    if (directPrerequisites.length > 0) {
      const prereqRecords = await prisma.conceptMastery.findMany({
        where: {
          studentId,
          conceptId: { in: directPrerequisites },
        },
      });

      for (const pr of directPrerequisites) {
        const found = prereqRecords.find((r) => r.conceptId === pr);
        prereqMasteries[pr] = found ? found.mastery : DEFAULT_BKT_PARAMS.pL0;
      }
    }

    const prereqUpdates = propagateToPrerequisites(
      bktResult.delta,
      prereqMasteries,
      DEFAULT_BKT_PARAMS
    );

    // 5. Misconception Detection if incorrect and reasoning provided
    let detectedMisconception = null;
    if (!isCorrect && studentReason.trim().length > 0) {
      try {
        detectedMisconception = await detectMisconception({
          studentReason,
          conceptId,
          questionText: question.text,
        });
      } catch (err) {
        console.warn("Misconception detection error:", err);
      }
    }

    // 6. Persist Target Concept Update in SQLite
    await prisma.conceptMastery.upsert({
      where: {
        studentId_conceptId: {
          studentId,
          conceptId,
        },
      },
      update: {
        mastery: bktResult.updatedMastery,
        attemptsCount: { increment: 1 },
        correctCount: isCorrect ? { increment: 1 } : undefined,
        lastReviewedAt: new Date(),
      },
      create: {
        studentId,
        conceptId,
        mastery: bktResult.updatedMastery,
        attemptsCount: 1,
        correctCount: isCorrect ? 1 : 0,
      },
    });

    // 7. Persist Prerequisite Updates in SQLite
    for (const [prereqId, updateInfo] of Object.entries(prereqUpdates)) {
      await prisma.conceptMastery.upsert({
        where: {
          studentId_conceptId: {
            studentId,
            conceptId: prereqId,
          },
        },
        update: {
          mastery: updateInfo.updatedMastery,
          lastReviewedAt: new Date(),
        },
        create: {
          studentId,
          conceptId: prereqId,
          mastery: updateInfo.updatedMastery,
        },
      });
    }

    // 8. Record QuestionAttempt Log
    const attemptLog = await prisma.questionAttempt.create({
      data: {
        studentId,
        questionId,
        conceptId,
        isCorrect,
        studentAnswer: selectedOptionId,
        studentReason: studentReason || null,
        misconceptionId: detectedMisconception?.matched ? detectedMisconception.misconceptionId : null,
        priorMastery,
        posteriorMastery: bktResult.updatedMastery,
      },
    });

    return NextResponse.json({
      success: true,
      isCorrect,
      explanation: question.explanation,
      bkt: {
        conceptId,
        prior: priorMastery,
        posterior: bktResult.posterior,
        updatedMastery: bktResult.updatedMastery,
        delta: bktResult.delta,
      },
      prerequisiteUpdates: prereqUpdates,
      misconception: detectedMisconception,
      attemptId: attemptLog.id,
    });
  } catch (error) {
    console.error("Error processing attempt:", error);
    return NextResponse.json(
      { success: false, error: "Failed to process attempt" },
      { status: 500 }
    );
  }
}
