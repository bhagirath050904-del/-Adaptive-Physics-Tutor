"use client";

import React, { useState } from "react";
import {
  CheckCircle2,
  XCircle,
  Sparkles,
  ArrowRight,
  BrainCircuit,
  RefreshCw,
  AlertTriangle,
  Lightbulb,
  Zap,
  TrendingUp,
  TrendingDown,
} from "lucide-react";

export interface QuestionData {
  id: string;
  conceptId: string;
  difficulty: string;
  pedagogicalReason: string;
  text: string;
  options: { id: string; text: string }[];
  correctOptionId: string;
  explanation: string;
}

export interface BKTUpdateResult {
  conceptId: string;
  prior: number;
  posterior: number;
  updatedMastery: number;
  delta: number;
}

export interface PrereqUpdateResult {
  prior: number;
  updatedMastery: number;
  delta: number;
}

export interface MisconceptionResult {
  matched: boolean;
  misconceptionId: string | null;
  confidence: number;
  explanation: string;
}

interface QuestionCardProps {
  question: QuestionData;
  targetConceptName: string;
  onSubmitAnswer: (params: {
    questionId: string;
    conceptId: string;
    selectedOptionId: string;
    studentReason: string;
  }) => Promise<{
    isCorrect: boolean;
    explanation: string;
    bkt: BKTUpdateResult;
    prerequisiteUpdates: Record<string, PrereqUpdateResult>;
    misconception: MisconceptionResult | null;
  }>;
  onNextQuestion?: () => void;
  isLoading?: boolean;
}

export function QuestionCard({
  question,
  targetConceptName,
  onSubmitAnswer,
  onNextQuestion,
  isLoading = false,
}: QuestionCardProps) {
  const [selectedOption, setSelectedOption] = useState<string>("");
  const [studentReason, setStudentReason] = useState<string>("");
  const [submitting, setSubmitting] = useState<boolean>(false);
  const [result, setResult] = useState<{
    isCorrect: boolean;
    explanation: string;
    bkt: BKTUpdateResult;
    prerequisiteUpdates: Record<string, PrereqUpdateResult>;
    misconception: MisconceptionResult | null;
  } | null>(null);

  const handleSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!selectedOption || submitting) return;

    setSubmitting(true);
    try {
      const res = await onSubmitAnswer({
        questionId: question.id,
        conceptId: question.conceptId,
        selectedOptionId: selectedOption,
        studentReason,
      });
      setResult(res);
    } catch (err) {
      console.error("Submission failed:", err);
    } finally {
      setSubmitting(false);
    }
  };

  const handleResetForNext = () => {
    setSelectedOption("");
    setStudentReason("");
    setResult(null);
    if (onNextQuestion) onNextQuestion();
  };

  return (
    <div className="flex flex-col h-full bg-slate-900/80 backdrop-blur-xl rounded-2xl border border-slate-800/80 p-5 lg:p-6 shadow-2xl text-slate-100 overflow-y-auto">
      {/* Pedagogical Transparency Reason Banner */}
      <div className="mb-4 relative overflow-hidden rounded-xl border border-cyan-500/30 bg-gradient-to-r from-cyan-950/40 via-slate-900/60 to-blue-950/40 p-4 shadow-inner">
        <div className="absolute -top-10 -right-10 w-24 h-24 bg-cyan-500/10 rounded-full blur-xl pointer-events-none" />
        <div className="flex items-start gap-3">
          <div className="p-1.5 rounded-lg bg-cyan-500/20 text-cyan-400 shrink-0 border border-cyan-500/30 mt-0.5">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-[11px] font-bold uppercase tracking-wider text-cyan-300">
                Pedagogical Transparency
              </span>
              <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-cyan-950 text-cyan-400 border border-cyan-800">
                Why this question?
              </span>
            </div>
            <p className="text-xs italic text-cyan-100/90 leading-relaxed">
              &ldquo;{question.pedagogicalReason}&rdquo;
            </p>
          </div>
        </div>
      </div>

      {/* Target Concept Header */}
      <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-800/80">
        <div>
          <span className="text-[10px] font-mono uppercase text-slate-400 tracking-wider flex items-center gap-1.5">
            <Zap className="w-3 h-3 text-cyan-400" />
            Target Knowledge Component
          </span>
          <h2 className="text-base lg:text-lg font-bold text-slate-100 tracking-tight">
            {targetConceptName}
          </h2>
        </div>
        <span className="text-[10px] font-mono uppercase px-2.5 py-1 rounded-md bg-slate-800/80 border border-slate-700 text-slate-300 font-semibold shadow-sm">
          {question.difficulty}
        </span>
      </div>

      {/* Question Text */}
      <div className="mb-5 bg-slate-950/40 p-4 rounded-xl border border-slate-800/60">
        <p className="text-slate-100 font-medium text-sm lg:text-base leading-relaxed">
          {question.text}
        </p>
      </div>

      {/* Multiple Choice Options */}
      <div className="space-y-2.5 mb-5">
        {question.options.map((opt) => {
          const isSelected = selectedOption === opt.id;
          let optionStyle =
            "border-slate-800/80 bg-slate-950/50 hover:bg-slate-800/50 hover:border-slate-700 text-slate-200";

          if (result) {
            if (opt.id === question.correctOptionId) {
              optionStyle =
                "border-emerald-500 bg-emerald-950/40 text-emerald-100 ring-2 ring-emerald-500/40 shadow-lg shadow-emerald-950/40";
            } else if (isSelected && !result.isCorrect) {
              optionStyle =
                "border-rose-500 bg-rose-950/40 text-rose-100 ring-2 ring-rose-500/40 shadow-lg shadow-rose-950/40";
            } else {
              optionStyle =
                "opacity-45 border-slate-800/50 bg-slate-950/30 text-slate-400";
            }
          } else if (isSelected) {
            optionStyle =
              "border-cyan-500 bg-cyan-950/40 text-cyan-100 ring-2 ring-cyan-500/40 shadow-lg shadow-cyan-950/40";
          }

          return (
            <button
              key={opt.id}
              type="button"
              disabled={!!result || submitting}
              onClick={() => setSelectedOption(opt.id)}
              className={`w-full text-left p-3.5 rounded-xl border flex items-center gap-3.5 transition-all duration-200 select-none ${optionStyle}`}
            >
              <span
                className={`w-7 h-7 rounded-lg font-mono text-xs font-bold flex items-center justify-center shrink-0 border transition-colors ${
                  isSelected
                    ? "bg-cyan-500 text-slate-950 border-cyan-400 shadow-md shadow-cyan-500/30"
                    : "bg-slate-800/80 text-slate-300 border-slate-700"
                }`}
              >
                {opt.id}
              </span>
              <span className="text-xs lg:text-sm font-medium">{opt.text}</span>
            </button>
          );
        })}
      </div>

      {/* Student Reasoning Input (Diagnostic for Misconceptions) */}
      {!result && (
        <div className="mb-5">
          <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <Lightbulb className="w-3.5 h-3.5 text-amber-400" />
              Explain Your Thinking:
            </span>
            <span className="text-[10px] text-slate-500 font-normal">
              Used for diagnostic misconception detection
            </span>
          </label>
          <textarea
            rows={2}
            value={studentReason}
            onChange={(e) => setStudentReason(e.target.value)}
            placeholder="Type your reasoning here (e.g. Current decreases after the first bulb because energy is consumed...)"
            className="w-full text-xs rounded-xl border border-slate-800 bg-slate-950/80 p-3 text-slate-200 placeholder:text-slate-600 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition-all resize-none"
          />
        </div>
      )}

      {/* Submission CTA */}
      {!result ? (
        <button
          type="button"
          onClick={() => handleSubmit()}
          disabled={!selectedOption || submitting || isLoading}
          className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-cyan-600 via-cyan-500 to-blue-600 hover:from-cyan-500 hover:to-blue-500 disabled:opacity-50 disabled:cursor-not-allowed font-semibold text-xs lg:text-sm text-white shadow-xl shadow-cyan-900/30 transition-all flex items-center justify-center gap-2 select-none active:scale-[0.99]"
        >
          {submitting ? (
            <>
              <RefreshCw className="w-4 h-4 animate-spin" />
              <span>Computing Bayesian Knowledge State...</span>
            </>
          ) : (
            <>
              <span>Submit Answer & Update Graph Mastery</span>
              <ArrowRight className="w-4 h-4" />
            </>
          )}
        </button>
      ) : (
        /* Result Breakdown & BKT Math Inspector */
        <div className="space-y-4">
          <div
            className={`p-4 rounded-xl border flex items-start gap-3.5 shadow-lg ${
              result.isCorrect
                ? "bg-emerald-950/40 border-emerald-500/60 text-emerald-200 shadow-emerald-950/30"
                : "bg-rose-950/40 border-rose-500/60 text-rose-200 shadow-rose-950/30"
            }`}
          >
            {result.isCorrect ? (
              <CheckCircle2 className="w-5 h-5 text-emerald-400 mt-0.5 shrink-0" />
            ) : (
              <XCircle className="w-5 h-5 text-rose-400 mt-0.5 shrink-0" />
            )}
            <div>
              <h4 className="font-bold text-sm">
                {result.isCorrect
                  ? "Correct Answer! Concept Reinforced"
                  : "Incorrect Answer — Review Recommended"}
              </h4>
              <p className="text-xs text-slate-300 mt-1.5 leading-relaxed">
                {result.explanation}
              </p>
            </div>
          </div>

          {/* Misconception Diagnostic Alert if matched */}
          {result.misconception?.matched && (
            <div className="p-4 rounded-xl border border-amber-600/70 bg-gradient-to-r from-amber-950/50 to-slate-900/70 text-amber-200 text-xs shadow-lg shadow-amber-950/30">
              <div className="flex items-center gap-2 font-bold text-amber-300 mb-1.5">
                <AlertTriangle className="w-4 h-4 text-amber-400" />
                <span>Misconception Detected: {result.misconception.misconceptionId}</span>
                <span className="ml-auto text-[10px] font-mono bg-amber-500/20 px-2 py-0.5 rounded border border-amber-500/40">
                  {Math.round(result.misconception.confidence * 100)}% match
                </span>
              </div>
              <p className="text-amber-200/90 leading-relaxed">
                {result.misconception.explanation}
              </p>
            </div>
          )}

          {/* BKT Math Inspector Card */}
          <div className="p-4 rounded-xl border border-slate-800 bg-slate-950/80 shadow-lg">
            <div className="flex items-center justify-between pb-2 mb-3 border-b border-slate-800 text-xs font-semibold text-slate-300">
              <span className="flex items-center gap-1.5">
                <BrainCircuit className="w-4 h-4 text-cyan-400" />
                Bayesian Knowledge Tracing (BKT) Inspector
              </span>
              <span
                className={`font-mono font-bold flex items-center gap-1 text-xs ${
                  result.bkt.delta >= 0 ? "text-emerald-400" : "text-rose-400"
                }`}
              >
                {result.bkt.delta >= 0 ? (
                  <TrendingUp className="w-3.5 h-3.5" />
                ) : (
                  <TrendingDown className="w-3.5 h-3.5" />
                )}
                {result.bkt.delta >= 0
                  ? `+${(result.bkt.delta * 100).toFixed(1)}%`
                  : `${(result.bkt.delta * 100).toFixed(1)}%`}
              </span>
            </div>

            <div className="grid grid-cols-3 gap-2 text-center text-xs mb-3">
              <div className="bg-slate-900/90 p-2.5 rounded-lg border border-slate-800">
                <div className="text-[10px] text-slate-500 uppercase font-mono">
                  Prior P(L₀)
                </div>
                <div className="font-mono font-bold text-slate-200 mt-0.5">
                  {(result.bkt.prior * 100).toFixed(1)}%
                </div>
              </div>
              <div className="bg-slate-900/90 p-2.5 rounded-lg border border-slate-800">
                <div className="text-[10px] text-slate-500 uppercase font-mono">
                  Posterior
                </div>
                <div className="font-mono font-bold text-cyan-300 mt-0.5">
                  {(result.bkt.posterior * 100).toFixed(1)}%
                </div>
              </div>
              <div className="bg-slate-900/90 p-2.5 rounded-lg border border-slate-800">
                <div className="text-[10px] text-slate-500 uppercase font-mono">
                  New Mastery
                </div>
                <div className="font-mono font-bold text-emerald-400 mt-0.5">
                  {(result.bkt.updatedMastery * 100).toFixed(1)}%
                </div>
              </div>
            </div>

            {/* Prerequisite Attenuations */}
            {Object.keys(result.prerequisiteUpdates).length > 0 && (
              <div className="mt-3 pt-2.5 border-t border-slate-800/80 text-[11px]">
                <span className="text-slate-400 font-medium block mb-1.5 flex items-center gap-1">
                  <span>Prerequisite Updates Propagated (α = 0.35):</span>
                </span>
                <div className="space-y-1.5">
                  {Object.entries(result.prerequisiteUpdates).map(([pid, pinfo]) => (
                    <div
                      key={pid}
                      className="flex items-center justify-between text-slate-300 bg-slate-900/60 px-3 py-1.5 rounded-lg border border-slate-800/60"
                    >
                      <span className="font-mono text-slate-400 text-[10px]">
                        {pid}
                      </span>
                      <span className="font-mono text-cyan-300 text-[11px] font-semibold">
                        {(pinfo.prior * 100).toFixed(0)}% →{" "}
                        {(pinfo.updatedMastery * 100).toFixed(0)}% (
                        {pinfo.delta >= 0
                          ? `+${(pinfo.delta * 100).toFixed(1)}%`
                          : `${(pinfo.delta * 100).toFixed(1)}%`}
                        )
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          <button
            type="button"
            onClick={handleResetForNext}
            className="w-full py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs border border-slate-700 transition-all flex items-center justify-center gap-2 shadow-md active:scale-[0.99]"
          >
            <span>Next Practice Question / Re-Attempt</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      )}
    </div>
  );
}
