# SPEC.md: Adaptive Physics Tutor (Class 10 CBSE Electricity)

## 1. Project Overview & Problem Statement
Adaptive Physics Tutor is a personalized exam-prep tutor for Class 10 CBSE Physics focusing exclusively on the **Electricity** chapter. 

Standard tutoring software tracks binary metrics: whether an answer was correct or incorrect. In contrast, this tutor maintains an explicit cognitive model of the learner:
- It tracks the learner's true probability of concept mastery using **Bayesian Knowledge Tracing (BKT)**.
- It understands the hierarchical dependencies of concepts (e.g., Ohm's law forms the foundation for parallel and series circuits, which leads to electric power).
- When a student answers incorrectly, it analyzes their reasoning against a **ground-truth library of physics misconceptions** to pinpoint cognitive errors.
- Every pedagogical action is transparent: every question presented to the student states *why* it is being asked (e.g., *"I'm asking this because you showed misconception MC_CURRENT_CONSUMED on Electric Current"*).

---

## 2. Technical Stack
- **Framework:** Next.js (App Router, TypeScript)
- **Styling:** Tailwind CSS + Radix/Lucide icons
- **State & Database:** SQLite with Prisma ORM
- **Graph Visualization:** React Flow (`@xyflow/react`) for concept DAG visualization with dynamic mastery coloring
- **Analytics & Charts:** Recharts (for student mastery progress and teacher heatmap/distributions)
- **Deterministic Math Engine:** Pure TypeScript implementation of Bayesian Knowledge Tracing (no LLMs involved in math)
- **Unit Testing:** Vitest / Node test runner for deterministic BKT verification
- **LLM Layer:** Single isolated wrapper (`lib/llm.ts`) with structured JSON schema enforcement, reading `GEMINI_API_KEY` (or generic `LLM_API_KEY`) from environment variables

---

## 3. Scope & Constraints
- **In Scope for Hackathon:**
  1. Concept Graph of 15 Class 10 CBSE Electricity concepts stored in JSON.
  2. Deterministic BKT learner model with prerequisite credit/penalty propagation + unit tests.
  3. 8-question adaptive diagnostic test covering the graph.
  4. Misconception detector using LLM matching against a strictly constrained JSON library.
  5. Weakest-concept question generator with 2-pass validation (blind solver pass).
  6. SM-2 spaced repetition interval scheduler.
  7. Teacher dashboard featuring a 20-student mastery heatmap and top-5 misconception summary.
  8. Student UI with React Flow graph color transition (Red $\rightarrow$ Yellow $\rightarrow$ Green) and question reasoning banner.
- **Explicit Non-Goals:**
  - No user authentication or registration (uses seeded / local session student ID).
  - No multi-chapter support (strictly Electricity).
  - No advanced mobile responsive polish (desktop/tablet web focused).

---

## 4. Concept Graph Architecture (`concepts.json`)
The 15 Electricity concepts form a Directed Acyclic Graph (DAG) capturing prerequisite relationships:

```mermaid
graph TD
    C1[1. Electric Charge] --> C2[2. Electric Current & Circuits]
    C1 --> C3[3. Potential Difference & Voltage]
    C2 --> C4[4. Ohm's Law]
    C3 --> C4
    C4 --> C5[5. Resistance & Factors Affecting It]
    C5 --> C6[6. Resistivity of Materials]
    C5 --> C7[7. Series Circuit Resistors]
    C2 --> C8[8. Current in Series Circuits]
    C7 --> C8
    C5 --> C9[9. Parallel Circuit Resistors]
    C3 --> C10[10. Voltage in Parallel Circuits]
    C9 --> C10
    C4 --> C11[11. Heating Effect & Joule's Law]
    C11 --> C12[12. Practical Heating: Fuses & Bulbs]
    C4 --> C13[13. Electric Power Equations]
    C8 --> C13
    C10 --> C13
    C13 --> C14[14. Power-Resistance Interrelation]
    C13 --> C15[15. Commercial Energy: kWh]
```

### Concept Definitions
1. `concept_electric_charge`: $Q = ne$, SI unit Coulomb.
2. `concept_electric_current`: $I = Q/t$, unit Ampere, conventional current vs electron drift.
3. `concept_potential_difference`: $V = W/Q$, unit Volt, work done moving unit charge.
4. `concept_ohms_law`: $V \propto I \implies V = IR$ at constant temperature.
5. `concept_resistance_factors`: $R \propto l/A$, effect of length, cross-sectional area, material.
6. `concept_resistivity`: Characteristic property $\rho = R \cdot A / l$ ($\Omega\cdot\text{m}$).
7. `concept_series_circuits`: Equivalent resistance $R_s = R_1 + R_2 + ... + R_n$.
8. `concept_current_in_series`: Identical current flows through all series components.
9. `concept_parallel_circuits`: Equivalent resistance $1/R_p = 1/R_1 + 1/R_2 + ... + 1/R_n$.
10. `concept_voltage_in_parallel`: Identical voltage across each branch in parallel.
11. `concept_joules_heating`: $H = I^2 R t = V I t = (V^2/R) t$.
12. `concept_heating_applications`: Safety fuse operation, tungsten filament in incandescent lamps.
13. `concept_electric_power`: Rate of electrical work $P = V I = I^2 R = V^2 / R$, unit Watt.
14. `concept_power_resistance_relation`: Contrast $P \propto R$ (series, constant $I$) vs $P \propto 1/R$ (parallel, constant $V$).
15. `concept_commercial_energy`: Kilowatt-hour ($1 \text{ kWh} = 3.6 \times 10^6 \text{ J}$), billing calculations.

---

## 5. Bayesian Knowledge Tracing (BKT) Learner Model

### Parameters per Concept
- $P(L_0) = 0.20$: Prior probability that a student already knows the concept.
- $P(T) = 0.15$: Transition probability (probability of acquiring knowledge during an opportunity).
- $P(G) = 0.20$: Guess probability (probability of answering correctly despite not knowing the concept).
- $P(S) = 0.10$: Slip probability (probability of making an error despite knowing the concept).
- $\alpha = 0.35$: Prerequisite attenuation factor (fraction of mastery update propagated upstream).

### Update Formulas

#### Step 1: Posterior Update Given Observation $y_t \in \{0, 1\}$
$$P(L_t \mid y_t = 1) = \frac{P(L_{t-1}) \cdot (1 - P(S))}{P(L_{t-1}) \cdot (1 - P(S)) + (1 - P(L_{t-1})) \cdot P(G)}$$

$$P(L_t \mid y_t = 0) = \frac{P(L_{t-1}) \cdot P(S)}{P(L_{t-1}) \cdot P(S) + (1 - P(L_{t-1})) \cdot (1 - P(G))}$$

#### Step 2: Next Practice Opportunity Transition
$$P(L_{t+1}) = P(L_t \mid y_t) + (1 - P(L_t \mid y_t)) \cdot P(T)$$

Clamped between $[0.01, 0.99]$.

#### Step 3: Upstream Prerequisite Propagation
When concept $C$ receives an update:
$$\Delta = P(L_{t+1}) - P(L_{t-1})$$
For each direct prerequisite $P \in \text{prerequisites}(C)$:
$$P_{new}(P) = \text{clamp}(P(P) + \alpha \cdot \Delta, 0.01, 0.99)$$
*(Recursively attenuated by $\alpha^k$ for higher order ancestors if needed, or single-step upstream propagation).*

---

## 6. Misconception Detection System
When a student answers incorrectly, they provide short natural language reasoning.

### Fixed Misconception Library (`misconceptions.json`)
- `MC_CURRENT_CONSUMED`: Believing current is "used up" by resistors and is lower after a resistor.
- `MC_VOLTAGE_IS_CURRENT`: Conflating potential difference with current flow.
- `MC_PARALLEL_RESISTANCE_SUM`: Believing adding parallel resistors increases net circuit resistance.
- `MC_BATTERY_CONSTANT_CURRENT`: Assuming batteries supply a fixed current regardless of the circuit resistance.
- `MC_SERIES_VOLTAGE_EQUAL`: Believing voltage splits equally in series regardless of individual resistance values.
- `MC_POWER_DIRECT_R_ALWAYS`: Using $P = I^2 R$ to claim higher resistance always means higher power in domestic (parallel) circuits.

### LLM Prompting & Schema Guard
The prompt includes the exact list of IDs and descriptions from `misconceptions.json`. The LLM wrapper enforces:
```json
{
  "matched": true,
  "misconceptionId": "MC_CURRENT_CONSUMED",
  "confidence": 0.92,
  "explanation": "Student thinks the bulb further along the wire receives less current because the first bulb consumed it."
}
```
If the student reasoning does not match any known misconception, `misconceptionId` returns `null` and `matched` is `false`. The model is strictly instructed never to fabricate new misconception IDs.

---

## 7. Question Generator with Two-Pass Blind Validation
1. **Pass 1 (Generation):** LLM receives target concept, target difficulty (easy, medium, hard), and syllabus constraints. Generates question, 4 choices, correct answer key, and explanation.
2. **Pass 2 (Independent Solve):** A fresh prompt containing *only* the question text and options is sent to the LLM (without the answer key or original explanation).
3. **Verification:**
   - If `Pass2_Answer === Pass1_Answer`: Question accepted into student session.
   - If `Pass2_Answer !== Pass1_Answer`: Question rejected; system logs disagreement and retries or falls back to curated question bank.

---

## 8. Spaced Repetition (SM-2 Algorithm)
For each concept $c$:
- Quality response $q \in [0, 5]$ mapped from BKT performance and misconception presence.
- Easiness Factor update: $EF' = \max(1.3, EF + (0.1 - (5 - q) \times (0.08 + (5 - q) \times 0.02)))$
- Repetition interval $I$:
  - If $n = 1: I_1 = 1 \text{ day}$
  - If $n = 2: I_2 = 6 \text{ days}$
  - If $n > 2: I_n = I_{n-1} \times EF'$

---

## 9. Teacher Dashboard
- Seeded with 20 realistic student profiles with varying mastery stages (struggling, moderate, advanced).
- **Mastery Heatmap:** 20 rows (students) $\times$ 15 columns (concepts) color-mapped from Red ($<40\%$) to Yellow ($40-70\%$) to Green ($>70\%$).
- **Top 5 Prevalent Misconceptions:** Frequency bar chart with click-through explanations.

---

## 10. Database Schema (Prisma + SQLite)
```prisma
datasource db {
  provider = "sqlite"
  url      = "file:./dev.db"
}

generator client {
  provider = "prisma-client-js"
}

model Student {
  id        String            @id @default(cuid())
  name      String
  masteries ConceptMastery[]
  attempts  QuestionAttempt[]
  createdAt DateTime          @default(now())
}

model ConceptMastery {
  id             String   @id @default(cuid())
  studentId      String
  conceptId      String
  mastery        Float    @default(0.20) // BKT P(L)
  attemptsCount  Int      @default(0)
  correctCount   Int      @default(0)
  lastReviewedAt DateTime @default(now())
  nextReviewAt   DateTime @default(now())
  easinessFactor Float    @default(2.5) // SM-2
  intervalDays   Int      @default(1)
  student        Student  @relation(fields: [studentId], references: [id], onDelete: Cascade)

  @@unique([studentId, conceptId])
}

model QuestionAttempt {
  id              String   @id @default(cuid())
  studentId       String
  questionId      String
  conceptId       String
  isCorrect       Boolean
  studentAnswer   String
  studentReason   String?
  misconceptionId String?
  priorMastery    Float
  posteriorMastery Float
  createdAt       DateTime @default(now())
  student         Student  @relation(fields: [studentId], references: [id], onDelete: Cascade)
}
```

---

## 11. Vertical Slice Scope (Phase 1 Target)
The vertical slice builds the exact thin end-to-end slice required:
1. Seed default student `demo-student`.
2. Render the 15-concept React Flow DAG showing node colors reflecting current BKT mastery:
   - $P(L) < 0.4$: Red (`#ef4444`)
   - $0.4 \le P(L) < 0.7$: Amber (`#f59e0b`)
   - $P(L) \ge 0.7$: Green (`#10b981`)
3. Question panel displaying a question for Ohm's Law (`concept_ohms_law`) with the pedagogical reason:
   *"I'm asking this because Ohm's Law is a foundational gateway to series, parallel, and power circuits."*
4. Student selects an answer and submits.
5. Next.js API route `/api/attempts` calculates deterministic BKT update for `concept_ohms_law`, attenuates update to prerequisite `concept_electric_current` and `concept_potential_difference`, and persists new values in SQLite via Prisma.
6. Frontend updates state: the matching node in React Flow smoothly transitions color (e.g. from Red to Amber/Green), showing updated mastery percentage.
7. Automated unit tests verify all BKT equations and prerequisite propagation.
