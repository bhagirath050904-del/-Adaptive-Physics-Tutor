"use client";

import React, { useState, type FC } from "react";
import { motion, MotionConfig, type Transition } from "motion/react";
import { ChevronDown, ArrowRight, Zap, BookOpen, Layers, CheckCircle2, Sparkles, Orbit } from "lucide-react";
import useMeasure from "react-use-measure";

export interface AccordionItemData {
  id: string | number;
  title: string;
  code?: string;
  icon?: React.ReactNode;
  content: string;
  mastery?: number;
  prerequisites?: string[];
  onSelect?: () => void;
}

interface AccordionItemProps {
  item: AccordionItemData;
  setOpenId: (id: string | number | null) => void;
  index: number;
  total: number;
  openIndex: number;
}

export interface AccordionProps {
  items?: AccordionItemData[];
  onSelectConcept?: (id: string) => void;
  selectedId?: string;
}

const springTransition: Transition = {
  type: "spring",
  stiffness: 550,
  damping: 45,
  mass: 1,
};

const DEFAULT_ITEMS: AccordionItemData[] = [
  {
    id: "c4_ohms_law",
    title: "Ohm's Law (V = IR)",
    code: "OHM",
    icon: <Zap className="w-4 h-4 text-amber-400" />,
    content:
      "Potential difference across conductor ends is directly proportional to current flowing through it at constant temperature: V = IR.",
    mastery: 0.20,
    prerequisites: ["Electric Current", "Potential Difference"],
  },
  {
    id: "c7_series_circuits",
    title: "Series Circuit Resistors (Rs = R1 + R2)",
    code: "SER_R",
    icon: <Layers className="w-4 h-4 text-cyan-400" />,
    content:
      "End-to-end combination with uniform current flowing through every resistor. Equivalent resistance is the algebraic sum of individual values.",
    mastery: 0.20,
    prerequisites: ["Resistance Factors", "Ohm's Law"],
  },
  {
    id: "c9_parallel_circuits",
    title: "Parallel Circuit Resistors (1/Rp = 1/R1 + 1/R2)",
    code: "PAR_R",
    icon: <Orbit className="w-4 h-4 text-purple-400" />,
    content:
      "Connected across common terminals with identical voltage across each branch. Total equivalent resistance is strictly less than the smallest individual resistor.",
    mastery: 0.20,
    prerequisites: ["Resistance Factors"],
  },
  {
    id: "c11_joules_heating",
    title: "Joule's Law of Heating (H = I²Rt)",
    code: "HEAT",
    icon: <Sparkles className="w-4 h-4 text-rose-400" />,
    content:
      "Heat generated in a resistor is directly proportional to square of current, resistance, and duration: H = I²Rt = VIt = (V²/R)t.",
    mastery: 0.20,
    prerequisites: ["Ohm's Law"],
  },
  {
    id: "c13_electric_power",
    title: "Electric Power (P = VI = I²R = V²/R)",
    code: "PWR",
    icon: <BookOpen className="w-4 h-4 text-emerald-400" />,
    content:
      "Rate at which electrical energy is consumed in a circuit. Standard unit is Watt (W) or Kilowatt (kW). 1 kWh = 3.6 × 10⁶ Joules.",
    mastery: 0.20,
    prerequisites: ["Series Circuits", "Parallel Circuits", "Ohm's Law"],
  },
];

const AccordionItem: FC<AccordionItemProps> = ({
  item,
  setOpenId,
  index,
  total,
  openIndex,
}) => {
  const [ref, bounds] = useMeasure();
  const isOpen = index === openIndex;

  const isFirst = index === 0;
  const isLast = index === total - 1;

  const isBeforeOpen = index === openIndex - 1;
  const isAfterOpen = index === openIndex + 1;

  const isAlone = (isAfterOpen && isLast) || (isBeforeOpen && isFirst);

  const BORDER_WIDTH = "1px";
  const BORDER_STYLE = "solid";
  const borderTopWidth =
    isFirst || isAfterOpen || isOpen ? BORDER_WIDTH : "0px";
  const borderBottomWidth =
    isLast || isBeforeOpen || isOpen ? BORDER_WIDTH : "0px";
  const borderLeftWidth = BORDER_WIDTH;
  const borderRightWidth = BORDER_WIDTH;

  let borderTopLeftRadius = 0;
  let borderTopRightRadius = 0;
  let borderBottomLeftRadius = 0;
  let borderBottomRightRadius = 0;

  if (isOpen || isAlone) {
    borderTopLeftRadius = 16;
    borderTopRightRadius = 16;
    borderBottomLeftRadius = 16;
    borderBottomRightRadius = 16;
  } else if (isBeforeOpen) {
    borderBottomLeftRadius = 16;
    borderBottomRightRadius = 16;
  } else if (isAfterOpen) {
    borderTopLeftRadius = 16;
    borderTopRightRadius = 16;
  } else if (isFirst) {
    borderTopLeftRadius = 16;
    borderTopRightRadius = 16;
  } else if (isLast) {
    borderBottomLeftRadius = 16;
    borderBottomRightRadius = 16;
  }

  const masteryVal = typeof item.mastery === "number" ? item.mastery : 0.2;
  const masteryPercent = Math.round(masteryVal * 100);

  let masteryBadge = "bg-rose-500/10 text-rose-400 border-rose-500/30";
  if (masteryVal >= 0.7) {
    masteryBadge = "bg-emerald-500/10 text-emerald-400 border-emerald-500/30";
  } else if (masteryVal >= 0.4) {
    masteryBadge = "bg-amber-500/10 text-amber-400 border-amber-500/30";
  }

  return (
    <MotionConfig transition={springTransition}>
      <motion.li layout className="list-none">
        <motion.div
          animate={{
            borderTopLeftRadius,
            borderTopRightRadius,
            borderBottomLeftRadius,
            borderBottomRightRadius,
          }}
          className={`overflow-hidden border-solid will-change-transform transition-colors duration-300 ${
            isOpen
              ? "border-cyan-500/50 bg-slate-900/95 shadow-xl shadow-cyan-950/20"
              : "border-slate-800/80 bg-slate-950/70 hover:bg-slate-900/60"
          }`}
          style={{
            borderTopWidth,
            borderBottomWidth,
            borderLeftWidth,
            borderRightWidth,
            borderStyle: BORDER_STYLE,
            marginBlock: isOpen ? "10px" : "0px",
          }}
        >
          <button
            type="button"
            onClick={() => setOpenId(isOpen ? null : item.id)}
            className="flex w-full cursor-pointer items-center justify-between px-4 py-3.5 text-left select-none"
          >
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-7 h-7 rounded-lg bg-slate-800/80 flex items-center justify-center shrink-0 border border-slate-700/60">
                {item.icon ?? <BookOpen className="w-4 h-4 text-cyan-400" />}
              </div>

              <div className="flex items-center gap-2 min-w-0">
                <span className="text-xs md:text-sm font-semibold text-slate-100 truncate">
                  {item.title}
                </span>
                {item.code && (
                  <span className="hidden sm:inline-block font-mono text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700">
                    {item.code}
                  </span>
                )}
              </div>
            </div>

            <div className="flex items-center gap-3 shrink-0 ml-2">
              <span className={`text-[11px] font-mono font-bold px-2 py-0.5 rounded border ${masteryBadge}`}>
                {masteryPercent}%
              </span>

              <motion.div animate={{ rotate: isOpen ? 180 : 0 }}>
                <ChevronDown className="w-4 h-4 text-slate-400" />
              </motion.div>
            </div>
          </button>

          <motion.div
            initial={false}
            animate={{
              height: isOpen ? bounds.height : 0,
              opacity: isOpen ? 1 : 0,
            }}
            className="overflow-hidden will-change-transform"
          >
            <div ref={ref}>
              <div className="px-5 pb-4 pt-1 text-xs text-slate-300 border-t border-slate-800/60">
                <p className="leading-relaxed text-slate-300 mb-3">{item.content}</p>

                {/* Prerequisite Tags */}
                {item.prerequisites && item.prerequisites.length > 0 && (
                  <div className="mb-3 flex items-center gap-1.5 flex-wrap text-[11px]">
                    <span className="text-slate-500 font-medium">Prerequisites:</span>
                    {item.prerequisites.map((p, idx) => (
                      <span
                        key={idx}
                        className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700 font-mono text-[10px]"
                      >
                        {p}
                      </span>
                    ))}
                  </div>
                )}

                {/* Action button if onSelect provided */}
                {item.onSelect && (
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      item.onSelect?.();
                    }}
                    className="w-full mt-2 py-2 px-3 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-semibold text-xs transition-colors flex items-center justify-center gap-1.5 shadow-md shadow-cyan-950/40"
                  >
                    <span>Practice Questions for this Concept</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>
          </motion.div>
        </motion.div>
      </motion.li>
    </MotionConfig>
  );
};

export const CardSplitAccordian: FC<AccordionProps> = ({
  items,
  onSelectConcept,
  selectedId,
}) => {
  const defaultItems = items ?? DEFAULT_ITEMS;
  const [openId, setOpenId] = useState<string | number | null>(selectedId ?? defaultItems[0]?.id ?? null);

  const openIndex = defaultItems.findIndex((item) => item.id === openId);

  return (
    <div className="flex w-full flex-col items-center justify-center p-2">
      <ul className="w-full space-y-0">
        {defaultItems.map((item, index) => (
          <AccordionItem
            key={item.id}
            item={{
              ...item,
              onSelect: onSelectConcept ? () => onSelectConcept(String(item.id)) : item.onSelect,
            }}
            setOpenId={setOpenId}
            index={index}
            total={defaultItems.length}
            openIndex={openIndex}
          />
        ))}
      </ul>
    </div>
  );
};

export default CardSplitAccordian;
