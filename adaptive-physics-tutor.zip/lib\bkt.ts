/**
 * Bayesian Knowledge Tracing (BKT) Core Engine
 * 
 * Deterministic implementation of standard BKT equations with:
 * 1. Posterior belief update based on observation (correct or incorrect)
 * 2. Knowledge acquisition transition step P(T)
 * 3. Upstream prerequisite attenuation propagation
 * 
 * All functions are pure and deterministic without LLM dependencies.
 */

export interface BKTParameters {
  /** Prior knowledge probability P(L0) */
  pL0: number;
  /** Transition probability P(T) - chance of acquiring knowledge on an opportunity */
  pT: number;
  /** Guess probability P(G) - chance of guessing right when not knowing */
  pG: number;
  /** Slip probability P(S) - chance of slipping when knowing */
  pS: number;
  /** Attenuation factor for prerequisite propagation (0 < alpha < 1) */
  alpha: number;
}

export const DEFAULT_BKT_PARAMS: BKTParameters = {
  pL0: 0.20,
  pT: 0.15,
  pG: 0.20,
  pS: 0.10,
  alpha: 0.35,
};

/**
 * Clamps a probability strictly into (0, 1) to avoid divide-by-zero or degenerate states.
 */
export function clampProbability(p: number, min = 0.01, max = 0.99): number {
  if (p < min) return min;
  if (p > max) return max;
  return Number(p.toFixed(4));
}

/**
 * Calculates posterior probability P(L_t | observation) given student's response.
 * 
 * @param prior - Prior mastery probability P(L_{t-1})
 * @param isCorrect - Whether the student answered correctly (true = 1, false = 0)
 * @param params - BKT parameters (pG, pS)
 */
export function calculatePosterior(
  prior: number,
  isCorrect: boolean,
  params: BKTParameters = DEFAULT_BKT_PARAMS
): number {
  const pPrior = clampProbability(prior);
  const { pG, pS } = params;

  if (isCorrect) {
    // P(L | correct) = (P(L) * (1 - P(S))) / [P(L) * (1 - P(S)) + (1 - P(L)) * P(G)]
    const numerator = pPrior * (1 - pS);
    const denominator = numerator + (1 - pPrior) * pG;
    return denominator === 0 ? pPrior : numerator / denominator;
  } else {
    // P(L | incorrect) = (P(L) * P(S)) / [P(L) * P(S) + (1 - P(L)) * (1 - P(G))]
    const numerator = pPrior * pS;
    const denominator = numerator + (1 - pPrior) * (1 - pG);
    return denominator === 0 ? pPrior : numerator / denominator;
  }
}

/**
 * Performs full BKT step: calculates posterior then incorporates learning transition P(T).
 * 
 * P(L_{t+1}) = P(L_t | obs) + (1 - P(L_t | obs)) * P(T)
 */
export function updateMastery(
  prior: number,
  isCorrect: boolean,
  params: BKTParameters = DEFAULT_BKT_PARAMS
): { posterior: number; updatedMastery: number; delta: number } {
  const posterior = calculatePosterior(prior, isCorrect, params);
  const updatedMasteryRaw = posterior + (1 - posterior) * params.pT;
  const updatedMastery = clampProbability(updatedMasteryRaw);
  const delta = Number((updatedMastery - prior).toFixed(4));

  return {
    posterior: clampProbability(posterior),
    updatedMastery,
    delta,
  };
}

/**
 * Calculates attenuated updates for prerequisite concepts.
 * A smaller update is propagated upstream to prerequisites:
 * Delta_p = alpha * delta
 * 
 * @param delta - The mastery change of the target concept
 * @param prerequisiteCurrentMasteries - Record of conceptId -> current mastery
 * @param params - BKT parameters containing alpha
 */
export function propagateToPrerequisites(
  delta: number,
  prerequisiteCurrentMasteries: Record<string, number>,
  params: BKTParameters = DEFAULT_BKT_PARAMS
): Record<string, { prior: number; updatedMastery: number; delta: number }> {
  const attenuatedDelta = delta * params.alpha;
  const updates: Record<string, { prior: number; updatedMastery: number; delta: number }> = {};

  for (const [conceptId, prior] of Object.entries(prerequisiteCurrentMasteries)) {
    const rawNew = prior + attenuatedDelta;
    const clampedNew = clampProbability(rawNew);
    updates[conceptId] = {
      prior,
      updatedMastery: clampedNew,
      delta: Number((clampedNew - prior).toFixed(4)),
    };
  }

  return updates;
}
