"use client";

import React, { useState, useEffect, useMemo, useCallback } from "react";
import { ConceptGraph, ConceptItem } from "@/components/ConceptGraph";
import {
  QuestionCard,
  QuestionData,
  BKTUpdateResult,
  PrereqUpdateResult,
  MisconceptionResult,
} from "@/components/QuestionCard";
import { CardSplitAccordian, AccordionItemData } from "@/components/ui/card-split-accordian";
import {
  Atom,
  RotateCcw,
  Activity,
  ShieldCheck,
  HelpCircle,
  Network,
  Layers,
  Sparkles,
  CheckCircle2,
  BookOpen,
  Zap,
} from "lucide-react";

export default function StudentScreen() {
  const [concepts, setConcepts] = useState<ConceptItem[]>([]);
  const [questions, setQuestions] = useState<QuestionData[]>([]);
  const [selectedConceptId, setSelectedConceptId] = useState<string>("c4_ohms_law");
  const [recentlyUpdatedIds, setRecentlyUpdatedIds] = useState<string[]>([]);
  const [studentName, setStudentName] = useState<string>("Aarav Sharma");
  const [activeTab, setActiveTab] = useState<"graph" | "accordion">("graph");
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // Load initial tutor state from API
  const loadState = useCallback(async () => {
    try {
      setLoading(true);
      const res = await fetch("/api/state?studentId=demo-student");
      const data = await res.json();
      if (data.success) {
        setConcepts(data.concepts);
        setQuestions(data.questions);
        setStudentName(data.student.name);
      } else {
        setError(data.error || "Failed to load tutor state");
      }
    } catch (err) {
      console.error("State loading error:", err);
      setError("Network error fetching state");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadState();
  }, [loadState]);

  // Currently focused concept
  const currentConcept = useMemo(() => {
    return (
      concepts.find((c) => c.id === selectedConceptId) ||
      concepts.find((c) => c.id === "c4_ohms_law") ||
      concepts[0]
    );
  }, [concepts, selectedConceptId]);

  // Current question for the focused concept (or fallback)
  const currentQuestion = useMemo(() => {
    if (!questions || questions.length === 0) return null;
    const match = questions.find((q) => q.conceptId === selectedConceptId);
    return match || questions[0];
  }, [questions, selectedConceptId]);

  // Aggregated mastery statistics
  const overallMastery = useMemo(() => {
    if (concepts.length === 0) return 0;
    const sum = concepts.reduce((acc, c) => acc + c.mastery, 0);
    return Math.round((sum / concepts.length) * 100);
  }, [concepts]);

  const masteredCount = useMemo(() => {
    return concepts.filter((c) => c.mastery >= 0.7).length;
  }, [concepts]);

  // Convert concepts to CardSplitAccordian item format
  const accordionItems: AccordionItemData[] = useMemo(() => {
    return concepts.map((c) => {
      const prereqNames = c.prerequisites
        .map((pid) => concepts.find((cp) => cp.id === pid)?.name || pid);

      return {
        id: c.id,
        title: c.name,
        code: c.code,
        content: c.description,
        mastery: c.mastery,
        prerequisites: prereqNames,
        onSelect: () => setSelectedConceptId(c.id),
      };
    });
  }, [concepts]);

  // Handle question submission
  const handleSubmitAnswer = async (params: {
    questionId: string;
    conceptId: string;
    selectedOptionId: string;
    studentReason: string;
  }): Promise<{
    isCorrect: boolean;
    explanation: string;
    bkt: BKTUpdateResult;
    prerequisiteUpdates: Record<string, PrereqUpdateResult>;
    misconception: MisconceptionResult | null;
  }> => {
    const res = await fetch("/api/attempts", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        studentId: "demo-student",
        questionId: params.questionId,
        conceptId: params.conceptId,
        selectedOptionId: params.selectedOptionId,
        studentReason: params.studentReason,
      }),
    });

    const data = await res.json();
    if (!data.success) {
      throw new Error(data.error || "Attempt failed");
    }

    // Update local concept masteries immediately for smooth visual transition
    const updatedIds: string[] = [params.conceptId];

    setConcepts((prevConcepts) => {
      return prevConcepts.map((c) => {
        if (c.id === params.conceptId) {
          return { ...c, mastery: data.bkt.updatedMastery };
        }
        if (data.prerequisiteUpdates && data.prerequisiteUpdates[c.id]) {
          updatedIds.push(c.id);
          return {
            ...c,
            mastery: data.prerequisiteUpdates[c.id].updatedMastery,
          };
        }
        return c;
      });
    });

    // Trigger visual pulse on updated nodes
    setRecentlyUpdatedIds(updatedIds);
    setTimeout(() => {
      setRecentlyUpdatedIds([]);
    }, 3500);

    return data;
  };

  // Reset demo student masteries
  const handleReset = async () => {
    if (!confirm("Reset all 15 concepts back to prior P(L0) = 0.20?")) return;
    try {
      await fetch("/api/reset", { method: "POST" });
      await loadState();
      setRecentlyUpdatedIds([]);
    } catch (err) {
      console.error("Reset failed:", err);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-[#090d16] text-slate-300">
        <div className="flex flex-col items-center gap-3">
          <div className="relative">
            <Atom className="w-10 h-10 text-cyan-400 animate-spin" />
            <div className="absolute inset-0 w-10 h-10 bg-cyan-400/20 blur-lg rounded-full" />
          </div>
          <p className="text-sm font-semibold tracking-wide text-slate-200">
            Initializing Adaptive Physics Knowledge Graph...
          </p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-[#090d16] text-rose-300 p-6">
        <div className="bg-rose-950/40 border border-rose-800 p-6 rounded-2xl max-w-md text-center shadow-2xl">
          <p className="font-bold mb-2">Error Loading Data</p>
          <p className="text-xs text-rose-200/80 mb-4">{error}</p>
          <button
            onClick={loadState}
            className="px-4 py-2 bg-rose-600 hover:bg-rose-500 rounded-lg text-xs font-semibold text-white shadow-md"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-screen max-h-screen bg-[#090d16] text-slate-100 overflow-hidden">
      {/* Top Navigation Bar */}
      <header className="h-16 border-b border-slate-800/80 bg-slate-900/60 backdrop-blur-xl px-5 lg:px-6 flex items-center justify-between shrink-0 z-30">
        {/* Brand & Chapter Tag */}
        <div className="flex items-center gap-3.5">
          <div className="relative">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-500 via-blue-500 to-indigo-600 flex items-center justify-center shadow-lg shadow-cyan-500/20">
              <Atom className="w-5 h-5 text-white" />
            </div>
            <div className="absolute -inset-0.5 bg-cyan-400/30 rounded-xl blur-sm -z-10" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-sm lg:text-base font-bold tracking-tight text-white">
                Adaptive Physics Tutor
              </h1>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-950/80 text-cyan-300 border border-cyan-800/80 font-semibold">
                Class 10 CBSE • Electricity
              </span>
            </div>
            <p className="text-[10px] text-slate-400">
              Bayesian Knowledge Tracing & Pedagogical Concept Graph
            </p>
          </div>
        </div>

        {/* View Switcher Tabs in Center */}
        <div className="hidden md:flex items-center bg-slate-950/80 p-1 rounded-xl border border-slate-800 shadow-inner">
          <button
            type="button"
            onClick={() => setActiveTab("graph")}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeTab === "graph"
                ? "bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm"
                : "text-slate-400 hover:text-slate-200"
            }`}
          >
            <Network className="w-3.5 h-3.5" />
            <span>DAG Concept Graph</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab("accordion")}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeTab === "accordion"
                ? "bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm"
                : "text-slate-400 hover:text-slate-200"
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Card Split Accordion</span>
          </button>
        </div>

        {/* Right Stats & Demo Actions */}
        <div className="flex items-center gap-3 lg:gap-4">
          {/* Mastered Pill */}
          <div className="hidden sm:flex items-center gap-1.5 bg-slate-950/60 px-3 py-1.5 rounded-xl border border-slate-800 text-xs">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            <span className="text-slate-400">Mastered:</span>
            <span className="font-mono font-bold text-emerald-400">
              {masteredCount} / {concepts.length}
            </span>
          </div>

          {/* Chapter Mastery Overall */}
          <div className="flex items-center gap-2 bg-slate-950/60 px-3 py-1.5 rounded-xl border border-slate-800">
            <Activity className="w-3.5 h-3.5 text-cyan-400" />
            <span className="text-xs text-slate-400 hidden sm:inline">Chapter Mastery:</span>
            <span className="text-xs font-mono font-bold text-cyan-300">
              {overallMastery}%
            </span>
          </div>

          {/* Student Profile Pill */}
          <div className="flex items-center gap-2 bg-slate-950/60 px-3 py-1.5 rounded-xl border border-slate-800">
            <ShieldCheck className="w-3.5 h-3.5 text-blue-400" />
            <span className="text-xs text-slate-300 font-medium truncate max-w-[110px]">
              {studentName}
            </span>
          </div>

          {/* Reset Prior Demo Button */}
          <button
            onClick={handleReset}
            title="Reset masteries back to initial prior 0.20"
            className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-slate-200 bg-slate-800/60 hover:bg-slate-800 px-3 py-1.5 rounded-xl border border-slate-700/60 transition-colors shadow-sm"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span className="hidden lg:inline">Reset Prior</span>
          </button>
        </div>
      </header>

      {/* Main Workspace (Split View) */}
      <main className="flex-1 flex overflow-hidden p-4 lg:p-5 gap-4 lg:gap-5">
        {/* Left Panel: Question Answering Station (42%) */}
        <section className="w-full md:w-[45%] lg:w-[42%] max-w-[580px] h-full flex flex-col min-w-[340px]">
          {/* Quick Concept Switcher Chips */}
          <div className="mb-3 flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
            <span className="text-[10px] font-mono text-slate-500 uppercase tracking-wider shrink-0 flex items-center gap-1">
              <Zap className="w-3 h-3 text-cyan-400" /> Focus:
            </span>
            {questions.map((q) => {
              const c = concepts.find((cp) => cp.id === q.conceptId);
              const isSelected = selectedConceptId === q.conceptId;
              return (
                <button
                  key={q.id}
                  type="button"
                  onClick={() => setSelectedConceptId(q.conceptId)}
                  className={`text-[11px] font-medium px-2.5 py-1 rounded-lg border whitespace-nowrap transition-all ${
                    isSelected
                      ? "bg-cyan-500/20 text-cyan-300 border-cyan-500/50 shadow-sm"
                      : "bg-slate-900/60 text-slate-400 border-slate-800 hover:text-slate-200"
                  }`}
                >
                  {c ? c.name : q.conceptId}
                </button>
              );
            })}
          </div>

          {/* Question Card */}
          {currentQuestion ? (
            <QuestionCard
              question={currentQuestion}
              targetConceptName={currentConcept ? currentConcept.name : "Ohm's Law"}
              onSubmitAnswer={handleSubmitAnswer}
              onNextQuestion={() => {
                const nextCandidate = questions.find((q) => q.conceptId !== selectedConceptId);
                if (nextCandidate) {
                  setSelectedConceptId(nextCandidate.conceptId);
                }
              }}
            />
          ) : (
            <div className="p-8 bg-slate-900/60 rounded-2xl border border-slate-800 text-center text-slate-400 my-auto">
              <HelpCircle className="w-10 h-10 mx-auto mb-3 text-slate-500" />
              <p className="text-xs">Select any concept on the graph or accordion to begin practice.</p>
            </div>
          )}
        </section>

        {/* Right Panel: Concept Visualizer (Graph vs Card Split Accordion) (58%) */}
        <section className="flex-1 h-full flex flex-col min-w-0 rounded-2xl overflow-hidden border border-slate-800/80 bg-slate-950/60 shadow-2xl relative">
          {/* Mobile/Tablet View Toggle if header tabs are hidden */}
          <div className="md:hidden flex items-center justify-between p-3 border-b border-slate-800 bg-slate-900/60">
            <span className="text-xs font-semibold text-slate-300">Concept Visualization</span>
            <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800">
              <button
                onClick={() => setActiveTab("graph")}
                className={`px-2.5 py-1 text-xs rounded font-medium ${
                  activeTab === "graph" ? "bg-cyan-600 text-white" : "text-slate-400"
                }`}
              >
                Graph
              </button>
              <button
                onClick={() => setActiveTab("accordion")}
                className={`px-2.5 py-1 text-xs rounded font-medium ${
                  activeTab === "accordion" ? "bg-cyan-600 text-white" : "text-slate-400"
                }`}
              >
                Cards
              </button>
            </div>
          </div>

          {/* Active View Display */}
          {activeTab === "graph" ? (
            <div className="w-full h-full relative">
              <ConceptGraph
                concepts={concepts}
                selectedConceptId={selectedConceptId}
                onSelectConcept={(cid) => setSelectedConceptId(cid)}
                recentlyUpdatedIds={recentlyUpdatedIds}
              />
            </div>
          ) : (
            <div className="w-full h-full overflow-y-auto p-4 lg:p-6 bg-slate-950/80">
              <div className="max-w-2xl mx-auto mb-4 flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                    <Layers className="w-4 h-4 text-cyan-400" />
                    Electricity Syllabus & Concept Hierarchy
                  </h3>
                  <p className="text-xs text-slate-400">
                    Animated Card Split Accordion displaying formulas, prerequisites, and live BKT mastery.
                  </p>
                </div>
              </div>

              <div className="max-w-2xl mx-auto">
                <CardSplitAccordian
                  items={accordionItems}
                  selectedId={selectedConceptId}
                  onSelectConcept={(cid) => {
                    setSelectedConceptId(cid);
                  }}
                />
              </div>
            </div>
          )}
        </section>
      </main>
    </div>
  );
}
