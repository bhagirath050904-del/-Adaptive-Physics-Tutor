# Misconception Detection & Catalog

## 1. Overview
When a student answers incorrectly, the tutor prompts them to provide their reasoning in natural language.
The system then passes this reasoning through the structured LLM layer (`lib/llm.ts`) to diagnose the underlying cognitive mistake against a **strictly closed, fixed catalog of physics misconceptions** (`data/misconceptions.json`).

> [!IMPORTANT]
> **Strict Guardrail:** The LLM is instructed never to hallucinate or invent new misconception IDs outside the verified CBSE physics catalog. If no cataloged misconception matches with high confidence, the system returns `matched: false` and `misconceptionId: null`.

---

## 2. Fixed Misconception Catalog

### 1. `MC_CURRENT_CONSUMED`
- **Name:** Current is Consumed Along the Circuit
- **Target Concept:** `c2_electric_current`
- **Description:** Student believes electric current gets used up or diminishes as it flows through resistors or bulbs in a circuit.
- **Pedagogical Correction:** Current represents the conservation of charge flow rate. Charge cannot be created or destroyed; current leaving a resistor is identical to current entering it.

### 2. `MC_VOLTAGE_IS_CURRENT`
- **Name:** Conflation of Potential Difference and Current
- **Target Concept:** `c3_potential_diff`
- **Description:** Student treats voltage and current as interchangeable, asserting that "voltage flows through a wire" or quoting "a voltage of 2 Amperes".
- **Pedagogical Correction:** Voltage (potential difference) is the energy per unit charge that drives flow; current is the physical flow rate of charges.

### 3. `MC_BATTERY_CONSTANT_CURRENT`
- **Name:** Battery Delivers Fixed Current Regardless of Resistance
- **Target Concept:** `c4_ohms_law`
- **Description:** Student assumes a battery always outputs a fixed current (e.g., 5A) rather than maintaining a constant potential difference.
- **Pedagogical Correction:** An ideal battery maintains a fixed potential difference (voltage). Current output is determined dynamically by the total circuit resistance ($I = V/R$).

### 4. `MC_PARALLEL_RESISTANCE_SUM`
- **Name:** Adding Parallel Branches Increases Total Resistance
- **Target Concept:** `c9_parallel_circuits`
- **Description:** Student believes adding more resistors in parallel increases equivalent resistance like in series circuits.
- **Pedagogical Correction:** Each added parallel branch creates an additional conductive pathway for current, decreasing overall equivalent resistance: $\frac{1}{R_p} = \frac{1}{R_1} + \frac{1}{R_2}$.

### 5. `MC_SERIES_VOLTAGE_EQUAL`
- **Name:** Series Voltage Splits Equally Regardless of Resistance
- **Target Concept:** `c8_series_current`
- **Description:** Student claims that resistors in series always share voltage equally, even when their individual resistance values differ.
- **Pedagogical Correction:** In series, voltage divides in direct proportion to resistance ($V_1 = IR_1$, $V_2 = IR_2$). The larger resistor drops more voltage.

### 6. `MC_POWER_DIRECT_R_ALWAYS`
- **Name:** Higher Resistance Always Means Higher Power
- **Target Concept:** `c14_power_resistance_comp`
- **Description:** Student misapplies $P = I^2R$ to domestic parallel circuits, arguing that higher resistance devices draw higher power.
- **Pedagogical Correction:** In domestic parallel circuits, voltage is constant. Therefore, $P = V^2 / R$, meaning higher resistance draws less current and dissipates lower power.

### 7. `MC_RESISTIVITY_CHANGES_WITH_DIMENSIONS`
- **Name:** Resistivity Changes When Wire is Stretched or Cut
- **Target Concept:** `c6_resistivity`
- **Description:** Student confuses resistance with resistivity, asserting that cutting a wire in half halves its resistivity.
- **Pedagogical Correction:** Resistivity is an intrinsic material property that depends only on the material composition and temperature, not on dimensions length or area.

---

## 3. LLM Prompt & Schema Guardrail

```typescript
export interface MisconceptionDetectionResult {
  matched: boolean;
  misconceptionId: string | null;
  confidence: number; // 0.0 to 1.0
  explanation: string; // One-line pedagogical explanation
}
```

The system prompt enforces:
```
You are a strict physics pedagogy misconception analyzer for Class 10 CBSE Electricity.
RULES:
1. You must ONLY match to one of the exact IDs in the provided catalog.
2. If the reasoning does not clearly match any of these specific misconceptions, you MUST return matched: false and misconceptionId: null.
3. NEVER invent or hallucinate a new misconception ID.
4. Output strictly valid JSON matching the schema.
```
