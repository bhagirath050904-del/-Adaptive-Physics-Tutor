import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import conceptsData from "@/data/concepts.json";

export async function POST() {
  try {
    const studentId = "demo-student";

    // Delete attempts
    await prisma.questionAttempt.deleteMany({
      where: { studentId },
    });

    // Reset masteries to 0.20
    for (const c of conceptsData) {
      await prisma.conceptMastery.upsert({
        where: {
          studentId_conceptId: {
            studentId,
            conceptId: c.id,
          },
        },
        update: {
          mastery: 0.20,
          attemptsCount: 0,
          correctCount: 0,
          lastReviewedAt: new Date(),
        },
        create: {
          studentId,
          conceptId: c.id,
          mastery: 0.20,
        },
      });
    }

    return NextResponse.json({ success: true, message: "Reset to initial prior P(L0) = 0.20" });
  } catch (error) {
    console.error("Reset error:", error);
    return NextResponse.json({ success: false, error: "Reset failed" }, { status: 500 });
  }
}
