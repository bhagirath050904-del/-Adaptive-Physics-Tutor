/**
 * LLM Wrapper Module
 * 
 * Provides unified, structured JSON generation with:
 * 1. Strict schema compliance (always returns typed JSON).
 * 2. API key read dynamically from environment variable (GEMINI_API_KEY or LLM_API_KEY).
 * 3. Fallback heuristic/mock support when no API key is configured, preventing hackathon demo failures.
 */

import misconceptionsData from "../data/misconceptions.json";

export interface LLMRequestParams {
  systemPrompt: string;
  userPrompt: string;
  temperature?: number;
}

export interface MisconceptionDetectionResult {
  matched: boolean;
  misconceptionId: string | null;
  confidence: number;
  explanation: string;
}

export interface GeneratedQuestion {
  id: string;
  conceptId: string;
  difficulty: "easy" | "medium" | "hard";
  pedagogicalReason: string;
  text: string;
  options: { id: string; text: string }[];
  correctOptionId: string;
  explanation: string;
  validationStatus: "validated" | "rejected";
}

/**
 * Universal structured LLM call.
 * Enforces JSON output and reads API key from process.env.
 */
export async function callStructuredLLM<T>(params: LLMRequestParams): Promise<T> {
  const apiKey = process.env.GEMINI_API_KEY || process.env.LLM_API_KEY || process.env.OPENAI_API_KEY;

  if (!apiKey) {
    console.warn("[LLM Wrapper] No GEMINI_API_KEY / LLM_API_KEY found in environment. Using fallback evaluator.");
    return fallbackStructuredEvaluator<T>(params);
  }

  try {
    // Standard Gemini 1.5 Flash API endpoint
    const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`;

    const payload = {
      contents: [
        {
          role: "user",
          parts: [
            { text: `${params.systemPrompt}\n\nSTRICT REQUIREMENT: Reply ONLY with valid JSON. Do not wrap in markdown or markdown backticks.\n\n${params.userPrompt}` }
          ]
        }
      ],
      generationConfig: {
        temperature: params.temperature ?? 0.2,
        responseMimeType: "application/json"
      }
    };

    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });

    if (!res.ok) {
      const errText = await res.text();
      console.error("[LLM Wrapper] API request failed:", res.status, errText);
      return fallbackStructuredEvaluator<T>(params);
    }

    const data = await res.json();
    const rawContent = data?.candidates?.[0]?.content?.parts?.[0]?.text;

    if (!rawContent) {
      throw new Error("Empty response received from LLM API");
    }

    // Sanitize in case model included markdown fences
    const cleanJson = rawContent.replace(/```(?:json)?/gi, "").replace(/```/g, "").trim();
    return JSON.parse(cleanJson) as T;
  } catch (error) {
    console.error("[LLM Wrapper] Error during LLM generation:", error);
    return fallbackStructuredEvaluator<T>(params);
  }
}

/**
 * Deterministic fallback for local development or when API key is not yet set by the evaluator.
 */
function fallbackStructuredEvaluator<T>(params: { userPrompt: string }): T {
  const promptLower = params.userPrompt.toLowerCase();

  // If this is a misconception check
  if (promptLower.includes("misconception")) {
    if (promptLower.includes("consumed") || promptLower.includes("used up") || promptLower.includes("drops after bulb")) {
      return {
        matched: true,
        misconceptionId: "MC_CURRENT_CONSUMED",
        confidence: 0.94,
        explanation: "Reasoning indicates a belief that current gets consumed or diminished as it passes through loads."
      } as unknown as T;
    }
    if (promptLower.includes("battery") && (promptLower.includes("constant current") || promptLower.includes("fixed 5a"))) {
      return {
        matched: true,
        misconceptionId: "MC_BATTERY_CONSTANT_CURRENT",
        confidence: 0.91,
        explanation: "Student assumed the battery outputs a fixed current regardless of load resistance."
      } as unknown as T;
    }
    if (promptLower.includes("parallel") && (promptLower.includes("increases resistance") || promptLower.includes("more resistors more ohms"))) {
      return {
        matched: true,
        misconceptionId: "MC_PARALLEL_RESISTANCE_SUM",
        confidence: 0.89,
        explanation: "Student erroneously applied series addition to a parallel branch network."
      } as unknown as T;
    }

    // Default no-match
    return {
      matched: false,
      misconceptionId: null,
      confidence: 0.50,
      explanation: "Reasoning did not distinctly match any cataloged misconception in the physics library."
    } as unknown as T;
  }

  // Fallback for general JSON objects
  return {} as T;
}

/**
 * Compares student's reasoning to the fixed library of misconceptions.
 * STRICT: Must NEVER invent misconceptions outside the library.
 */
export async function detectMisconception(params: {
  studentReason: string;
  conceptId: string;
  questionText: string;
}): Promise<MisconceptionDetectionResult> {
  const allowedMisconceptions = misconceptionsData.map(m => ({
    id: m.id,
    name: m.name,
    conceptId: m.conceptId,
    description: m.description,
  }));

  const systemPrompt = `You are a strict physics pedagogy misconception analyzer for Class 10 CBSE Electricity.
You are given a student's answer reasoning on a physics question.
Compare the reasoning strictly to the following library of allowed misconceptions:
${JSON.stringify(allowedMisconceptions, null, 2)}

RULES:
1. You must ONLY match to one of the exact IDs in the list above: ${allowedMisconceptions.map(m => m.id).join(", ")}.
2. If the reasoning does not clearly match any of these specific misconceptions, you MUST return matched: false and misconceptionId: null.
3. NEVER invent or hallucinate a new misconception ID.
4. Output JSON format strictly matching:
{
  "matched": boolean,
  "misconceptionId": string | null,
  "confidence": number, // between 0.0 and 1.0
  "explanation": string // one-line explanation
}`;

  const userPrompt = `Concept ID: ${params.conceptId}
Question: ${params.questionText}
Student Reasoning: "${params.studentReason}"`;

  return callStructuredLLM<MisconceptionDetectionResult>({
    systemPrompt,
    userPrompt,
    temperature: 0.1,
  });
}
