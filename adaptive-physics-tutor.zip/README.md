# ⚛️ Adaptive Physics Tutor (Class 10 CBSE Electricity)

An intelligent, transparent exam-prep tutor for Class 10 CBSE Physics focusing on the **Electricity** chapter. 

Unlike traditional quiz applications that only evaluate binary right/wrong scores, **Adaptive Physics Tutor** tracks a probabilistic belief of student understanding using **Bayesian Knowledge Tracing (BKT)** across an interconnected **Concept DAG**, complete with prerequisite attenuation propagation, pedagogical transparency, and diagnostic misconception detection.

---

## 🚀 Key Features

- **🧠 Deterministic Bayesian Knowledge Tracing (BKT):**
  Pure TypeScript implementation calculating posterior mastery and learning transitions ($P(L_0) = 0.20, P(T) = 0.15, P(G) = 0.20, P(S) = 0.10$). No LLM involvement in probabilistic scoring.
- **🔗 Upstream Prerequisite Propagation:**
  Mastery gains or losses on composite concepts (e.g. *Ohm's Law*) pass an attenuated update ($\alpha = 0.35$) upstream to foundational prerequisite concepts (*Electric Current* and *Potential Difference*).
- **💡 Complete Pedagogical Transparency:**
  Every single question presents an explicit reason stating *why* it was selected for the student (e.g., *"I'm asking this because Ohm's Law is the foundational gateway linking potential difference, current flow, and subsequent circuit analysis."*).
- **🌐 Dual-Mode Concept Visualizer:**
  - **DAG Concept Graph:** Interactive 2D React Flow graph with dynamic mastery color transitions (**Red $<40\%$**, **Amber $40-69\%$**, **Emerald Green $\ge 70\%$**).
  - **Card Split Accordion:** Smooth spring-animated split accordion displaying syllabus details, formulas, and prerequisite relationships.
- **🔍 Misconception Diagnosis Engine:**
  When a student answers incorrectly and provides natural language reasoning, the LLM analyzes it strictly against a fixed catalog of CBSE physics misconceptions without hallucinating unlisted error modes.

---

## 🛠️ Tech Stack

| Layer | Technologies |
| :--- | :--- |
| **Frontend** | [Next.js 14 (App Router)](https://nextjs.org/), [TypeScript](https://www.typescriptlang.org/), [Tailwind CSS](https://tailwindcss.com/) |
| **Interactive Graph** | [React Flow (@xyflow/react)](https://reactflow.dev/) |
| **Animations** | [Motion](https://motion.dev/), [React Use Measure](https://github.com/pmndrs/react-use-measure) |
| **Database & ORM** | [SQLite](https://www.sqlite.org/), [Prisma ORM](https://www.prisma.io/) |
| **Math Engine** | Pure TypeScript Deterministic BKT Engine + [Vitest](https://vitest.dev/) |
| **LLM Integration** | Structured JSON schema wrapper (Google Gemini / generic LLM fallback) |

---

## 📚 Complete Documentation Folder (`/docs`)

All architectural specifications, mathematical models, and API references are documented in the [`docs/`](./docs) folder:

- 📖 [**Documentation Hub**](./docs/README.md): Overview and table of contents.
- 📐 [**System Architecture**](./docs/ARCHITECTURE.md): Component diagrams, dataflow, and folder structure.
- 🧮 [**BKT Learner Model**](./docs/BKT_MODEL.md): Formulas, parameters, and prerequisite attenuation proofs.
- 🌳 [**Concept Graph Taxonomy**](./docs/CONCEPT_GRAPH.md): 15-node DAG, equations, and CBSE syllabus connections.
- ⚠️ [**Misconception Catalog**](./docs/MISCONCEPTIONS.md): Fixed physics error library and prompt guardrails.
- 🔌 [**API Reference**](./docs/API_REFERENCE.md): Detailed payloads for `/api/state`, `/api/attempts`, and `/api/reset`.
- ⚡ [**Quickstart Guide**](./docs/QUICKSTART.md): Step-by-step setup, database seeding, and testing.
- 📋 [**Full Project Specification**](./docs/SPEC.md): Original complete specification document.

---

## ⚡ Quickstart

```bash
# 1. Clone repository
git clone <repository-url>
cd adaptive-physics-tutor

# 2. Install dependencies
npm install

# 3. Setup SQLite Database & Seed Data
npx prisma db push
node prisma/seed.js

# 4. Run Unit Tests (BKT Math Verification)
npm test

# 5. Start Development Server
npm run dev
```

Visit [http://localhost:3000](http://localhost:3000) in your browser.

---

## 🧪 Unit Testing

All Bayesian Knowledge Tracing mathematical invariants are verified using Vitest:

```bash
npm test
```

```
✓ lib/bkt.test.ts (7 tests)
  ✓ should clamp probabilities within valid numerical bounds [0.01, 0.99]
  ✓ should increase concept mastery on a correct answer
  ✓ should decrease concept mastery on an incorrect answer
  ✓ should propagate attenuated positive update to prerequisite concepts
  ✓ should propagate attenuated negative update to prerequisites on wrong answer
  ✓ should converge towards 0.99 with continuous correct answers
  ✓ should maintain strictly monotonic posterior with respect to prior
```

---

## 📄 License
MIT License.
