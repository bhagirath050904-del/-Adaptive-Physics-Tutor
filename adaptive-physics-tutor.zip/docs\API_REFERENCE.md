# API Reference

All backend endpoints are built using Next.js App Router Route Handlers.

---

## 1. `GET /api/state`
Retrieves student session info, the complete 15-concept graph enriched with current BKT mastery, questions, and recent attempt logs.

### Query Parameters
- `studentId` *(optional, string)*: Student ID (defaults to `"demo-student"`).

### Response (`200 OK`)
```json
{
  "success": true,
  "student": {
    "id": "demo-student",
    "name": "Aarav Sharma (Class 10 CBSE)"
  },
  "concepts": [
    {
      "id": "c4_ohms_law",
      "name": "Ohm's Law",
      "code": "OHM",
      "description": "Relationship between voltage and current at constant temperature: V = IR.",
      "prerequisites": ["c2_electric_current", "c3_potential_diff"],
      "position": { "x": 550, "y": 200 },
      "mastery": 0.60
    }
  ],
  "questions": [
    {
      "id": "q_ohm_01",
      "conceptId": "c4_ohms_law",
      "difficulty": "medium",
      "pedagogicalReason": "I'm asking this because Ohm's Law is the foundational gateway linking potential difference, current flow, and subsequent circuit analysis.",
      "text": "A conductor maintains a potential difference of 12 V across its ends while a steady current of 3 A flows through it...",
      "options": [
        { "id": "A", "text": "4 Ω (Ohms)" },
        { "id": "B", "text": "36 Ω (Ohms)" }
      ],
      "correctOptionId": "A",
      "explanation": "By Ohm's law, V = I * R..."
    }
  ],
  "recentAttempts": []
}
```

---

## 2. `POST /api/attempts`
Submits a student answer to a question. Triggers the deterministic BKT update on the target concept, calculates attenuated updates on upstream prerequisites, executes misconception detection if wrong reasoning is supplied, and records the attempt log in SQLite.

### Request Body
```json
{
  "studentId": "demo-student",
  "questionId": "q_ohm_01",
  "conceptId": "c4_ohms_law",
  "selectedOptionId": "A",
  "studentReason": "Applied V = IR hence R = V/I = 12/3 = 4 Ohms"
}
```

### Response (`200 OK`)
```json
{
  "success": true,
  "isCorrect": true,
  "explanation": "By Ohm's law, V = I * R. Substituting: 12 V = 3 A * R => R = 4 Ω.",
  "bkt": {
    "conceptId": "c4_ohms_law",
    "prior": 0.20,
    "posterior": 0.5294,
    "updatedMastery": 0.60,
    "delta": 0.40
  },
  "prerequisiteUpdates": {
    "c2_electric_current": {
      "prior": 0.20,
      "updatedMastery": 0.34,
      "delta": 0.14
    },
    "c3_potential_diff": {
      "prior": 0.20,
      "updatedMastery": 0.34,
      "delta": 0.14
    }
  },
  "misconception": null,
  "attemptId": "cmvw636tz0007f7lrb97rjmhe"
}
```

---

## 3. `POST /api/reset`
Resets the demo student's masteries across all 15 concepts back to the initial prior ($P(L_0) = 0.20$) and clears past attempt logs.

### Response (`200 OK`)
```json
{
  "success": true,
  "message": "Reset to initial prior P(L0) = 0.20"
}
```
