import React, { memo } from "react";
import { Handle, Position, type NodeProps } from "@xyflow/react";
import { Zap, CheckCircle2, AlertCircle, Clock } from "lucide-react";

export interface ConceptNodeData extends Record<string, unknown> {
  id: string;
  name: string;
  code: string;
  description: string;
  mastery: number; // 0.0 to 1.0
  isSelected?: boolean;
  isRecentlyUpdated?: boolean;
}

export const ConceptNode = memo((props: NodeProps) => {
  const data = props.data as unknown as ConceptNodeData;
  const { name, code, mastery = 0.2, isSelected, isRecentlyUpdated } = data;

  // Dynamic styling tiers based on BKT mastery
  let tier = {
    bg: "from-rose-950/40 to-slate-900/90 border-rose-500/50 shadow-rose-950/30",
    badge: "bg-rose-500/15 text-rose-300 border-rose-500/30",
    bar: "from-rose-600 to-rose-400",
    text: "text-rose-300",
    label: "Developing",
    icon: <AlertCircle className="w-3 h-3 text-rose-400" />,
  };

  if (mastery >= 0.70) {
    tier = {
      bg: "from-emerald-950/40 to-slate-900/90 border-emerald-500/50 shadow-emerald-950/30",
      badge: "bg-emerald-500/15 text-emerald-300 border-emerald-500/30",
      bar: "from-emerald-600 to-emerald-400",
      text: "text-emerald-300",
      label: "Mastered",
      icon: <CheckCircle2 className="w-3 h-3 text-emerald-400" />,
    };
  } else if (mastery >= 0.40) {
    tier = {
      bg: "from-amber-950/40 to-slate-900/90 border-amber-500/50 shadow-amber-950/30",
      badge: "bg-amber-500/15 text-amber-300 border-amber-500/30",
      bar: "from-amber-600 to-amber-400",
      text: "text-amber-300",
      label: "Progressing",
      icon: <Clock className="w-3 h-3 text-amber-400" />,
    };
  }

  const masteryPercent = Math.round(mastery * 100);

  return (
    <div
      className={`relative w-60 rounded-2xl border-2 p-3.5 backdrop-blur-xl bg-gradient-to-b shadow-xl transition-all duration-500 select-none cursor-pointer ${
        tier.bg
      } ${
        isSelected
          ? "ring-2 ring-cyan-400 ring-offset-2 ring-offset-slate-950 scale-105 z-20 shadow-cyan-500/20"
          : "hover:scale-[1.02] hover:border-slate-400/80"
      } ${
        isRecentlyUpdated ? "animate-pulse ring-4 ring-emerald-400 ring-offset-2 ring-offset-slate-950" : ""
      }`}
    >
      {/* Target Handle (Left: Prerequisites) */}
      <Handle
        type="target"
        position={Position.Left}
        className="!w-3.5 !h-3.5 !bg-slate-400 !border-2 !border-slate-950 transition-colors hover:!bg-cyan-400"
      />

      {/* Top Header: Code badge, Status Pill, Mastery % */}
      <div className="flex items-center justify-between gap-1 mb-2">
        <div className="flex items-center gap-1.5">
          <span className="font-mono text-[10px] font-bold px-2 py-0.5 rounded-md bg-slate-800 text-slate-300 border border-slate-700">
            {code}
          </span>
          <span className={`text-[10px] font-medium px-1.5 py-0.5 rounded flex items-center gap-1 border ${tier.badge}`}>
            {tier.icon}
            <span>{tier.label}</span>
          </span>
        </div>

        <span className={`font-mono text-xs font-extrabold ${tier.text}`}>
          {masteryPercent}%
        </span>
      </div>

      {/* Concept Name */}
      <h3 className="text-xs font-bold text-slate-100 line-clamp-2 min-h-[32px] leading-snug mb-2.5">
        {name}
      </h3>

      {/* Mastery Progress Bar */}
      <div className="w-full bg-slate-800/90 rounded-full h-2 overflow-hidden border border-slate-700/60 p-[1px]">
        <div
          className={`h-full rounded-full bg-gradient-to-r transition-all duration-700 ease-out ${tier.bar}`}
          style={{ width: `${masteryPercent}%` }}
        />
      </div>

      {/* Footer Info */}
      <div className="flex items-center justify-between text-[10px] text-slate-400 mt-2 pt-1.5 border-t border-slate-800/60 font-mono">
        <span className="text-slate-500">P(L) = {mastery.toFixed(2)}</span>
        <span className="text-cyan-400 hover:underline">Click to practice →</span>
      </div>

      {/* Source Handle (Right: Dependent Concepts) */}
      <Handle
        type="source"
        position={Position.Right}
        className="!w-3.5 !h-3.5 !bg-slate-400 !border-2 !border-slate-950 transition-colors hover:!bg-cyan-400"
      />
    </div>
  );
});

ConceptNode.displayName = "ConceptNode";
