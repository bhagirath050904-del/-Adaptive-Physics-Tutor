# Adaptive Physics Tutor - Documentation Hub

Welcome to the comprehensive technical documentation for **Adaptive Physics Tutor**, an intelligent exam-prep tutor designed for Class 10 CBSE Physics (Electricity Chapter).

Unlike conventional quiz systems that only record binary right/wrong percentages, this platform maintains a cognitive state model of the student using **Bayesian Knowledge Tracing (BKT)** across an interconnected **Directed Acyclic Graph (DAG)** of physical concepts, backed by an LLM-powered misconception diagnosis engine.

---

## Documentation Index

| Document | Purpose |
| :--- | :--- |
| [**System Architecture**](./ARCHITECTURE.md) | High-level architectural design, tech stack decisions, dataflow, and folder structure. |
| [**BKT Learner Model**](./BKT_MODEL.md) | Full mathematical formulations, posterior calculations, transition step, and prerequisite attenuation proofs. |
| [**Concept Graph (Electricity)**](./CONCEPT_GRAPH.md) | Taxonomy of all 15 CBSE Class 10 Electricity concepts, prerequisite dependencies, and equations. |
| [**Misconception Detection**](./MISCONCEPTIONS.md) | Fixed misconception catalog, pedagogical reasoning prompts, schema guardrails, and counseling responses. |
| [**API Reference**](./API_REFERENCE.md) | Detailed specifications for all Next.js API route handlers, request bodies, and responses. |
| [**Quickstart & Development**](./QUICKSTART.md) | Setup guide, Prisma database seeding, running local dev server, production build, and running unit tests. |

---

## Core System Highlights

- **Deterministic Math Engine:** Pure TypeScript implementation of Bayesian Knowledge Tracing without LLM involvement in probabilistic scoring.
- **Pedagogical Transparency:** Every question displays the explicit pedagogical rationale explaining *why* it was chosen for the student.
- **Prerequisite Propagation:** Updates to downstream concepts propagate attenuated mastery updates ($\alpha = 0.35$) upstream to foundational prerequisites.
- **Interactive Visualizers:** Dual-mode interface featuring both a 2D interactive React Flow DAG and an animated Watermelon UI / Gravitas **Card Split Accordion**.
