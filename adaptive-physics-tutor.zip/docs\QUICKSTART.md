# Quickstart & Developer Guide

## Prerequisites
- **Node.js**: v18.0.0 or higher (Tested on Node v24.16.0)
- **npm**: v9.0.0 or higher
- **Git**

---

## 1. Installation
Clone the repository and install dependencies:

```bash
git clone <your-repository-url>
cd adaptive-physics-tutor
npm install
```

---

## 2. Environment Configuration (Optional)
If you wish to test live LLM misconception detection against Google Gemini:

Create a `.env` file in the project root:
```env
GEMINI_API_KEY=your_gemini_api_key_here
```

*(If no API key is provided, the platform automatically utilizes its built-in heuristic fallback evaluator, so all core tutoring flows and tests work out-of-the-box offline).*

---

## 3. Database Setup & Seeding
Initialize the SQLite database schema via Prisma and seed the default student profile:

```bash
# Push schema to SQLite
npx prisma db push

# Seed default student and concept masteries
node prisma/seed.js
```

---

## 4. Running Unit Tests
Run the deterministic BKT mathematical verification test suite with Vitest:

```bash
npm test
```

Expected output:
```
✓ lib/bkt.test.ts (7 tests)
Test Files  1 passed (1)
Tests       7 passed (7)
```

---

## 5. Development Server
Start the local Next.js development server:

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

---

## 6. Production Build
Create an optimized production build:

```bash
npm run build
npm start
```
