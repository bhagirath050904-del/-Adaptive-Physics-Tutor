import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import conceptsData from "@/data/concepts.json";
import questionsData from "@/data/questions.json";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const studentId = searchParams.get("studentId") || "demo-student";

    // Ensure student exists
    let student = await prisma.student.findUnique({
      where: { id: studentId },
      include: { masteries: true },
    });

    if (!student) {
      student = await prisma.student.create({
        data: {
          id: studentId,
          name: "Aarav Sharma (Class 10 CBSE)",
          masteries: {
            create: conceptsData.map((c) => ({
              conceptId: c.id,
              mastery: 0.20,
            })),
          },
        },
        include: { masteries: true },
      });
    }

    // Map mastery by conceptId
    const masteryMap: Record<string, number> = {};
    for (const m of student.masteries) {
      masteryMap[m.conceptId] = m.mastery;
    }

    // Merge concepts with current mastery values
    const enrichedConcepts = conceptsData.map((c) => ({
      ...c,
      mastery: masteryMap[c.id] ?? 0.20,
    }));

    // Get recent attempts
    const recentAttempts = await prisma.questionAttempt.findMany({
      where: { studentId },
      orderBy: { createdAt: "desc" },
      take: 10,
    });

    return NextResponse.json({
      success: true,
      student: {
        id: student.id,
        name: student.name,
      },
      concepts: enrichedConcepts,
      questions: questionsData,
      recentAttempts,
    });
  } catch (error) {
    console.error("Error fetching state:", error);
    return NextResponse.json(
      { success: false, error: "Failed to fetch tutor state" },
      { status: 500 }
    );
  }
}
