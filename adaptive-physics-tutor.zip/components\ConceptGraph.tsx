"use client";

import React, { useMemo, useCallback } from "react";
import {
  ReactFlow,
  Background,
  Controls,
  MiniMap,
  Node,
  Edge,
  MarkerType,
  BackgroundVariant,
  NodeTypes,
} from "@xyflow/react";
import { ConceptNode, ConceptNodeData } from "./ConceptNode";

export interface ConceptItem {
  id: string;
  name: string;
  code: string;
  description: string;
  prerequisites: string[];
  position: { x: number; y: number };
  mastery: number;
}

interface ConceptGraphProps {
  concepts: ConceptItem[];
  selectedConceptId: string;
  onSelectConcept: (conceptId: string) => void;
  recentlyUpdatedIds?: string[];
}

const nodeTypes: NodeTypes = {
  conceptNode: ConceptNode,
};

export function ConceptGraph({
  concepts,
  selectedConceptId,
  onSelectConcept,
  recentlyUpdatedIds = [],
}: ConceptGraphProps) {
  // Convert concepts into React Flow Nodes
  const nodes: Node[] = useMemo(() => {
    return concepts.map((c) => ({
      id: c.id,
      type: "conceptNode",
      position: c.position,
      data: {
        id: c.id,
        name: c.name,
        code: c.code,
        description: c.description,
        mastery: c.mastery,
        isSelected: c.id === selectedConceptId,
        isRecentlyUpdated: recentlyUpdatedIds.includes(c.id),
      },
    }));
  }, [concepts, selectedConceptId, recentlyUpdatedIds]);

  // Build prerequisite edges
  const edges: Edge[] = useMemo(() => {
    const edgeList: Edge[] = [];
    concepts.forEach((c) => {
      c.prerequisites.forEach((prereqId) => {
        const isHighlight =
          c.id === selectedConceptId || prereqId === selectedConceptId;

        edgeList.push({
          id: `e-${prereqId}-${c.id}`,
          source: prereqId,
          target: c.id,
          animated: isHighlight,
          style: {
            stroke: isHighlight ? "#38bdf8" : "#475569",
            strokeWidth: isHighlight ? 2.5 : 1.5,
          },
          markerEnd: {
            type: MarkerType.ArrowClosed,
            width: 16,
            height: 16,
            color: isHighlight ? "#38bdf8" : "#475569",
          },
        });
      });
    });
    return edgeList;
  }, [concepts, selectedConceptId]);

  const onNodeClick = useCallback(
    (_: React.MouseEvent, node: Node) => {
      onSelectConcept(node.id);
    },
    [onSelectConcept]
  );

  return (
    <div className="w-full h-full min-h-[500px] rounded-xl border border-slate-800 bg-slate-950/60 overflow-hidden relative shadow-2xl">
      {/* Concept Graph Legend Banner */}
      <div className="absolute top-4 left-4 z-10 flex items-center gap-3 bg-slate-900/90 backdrop-blur-md px-3.5 py-2 rounded-lg border border-slate-700/70 text-xs shadow-md">
        <span className="font-semibold text-slate-300">Mastery Legend:</span>
        <div className="flex items-center gap-1.5">
          <span className="w-2.5 h-2.5 rounded-full bg-rose-500 inline-block" />
          <span className="text-slate-400">&lt; 40% (Developing)</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="w-2.5 h-2.5 rounded-full bg-amber-500 inline-block" />
          <span className="text-slate-400">40 - 69% (Progressing)</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 inline-block" />
          <span className="text-slate-400">≥ 70% (Mastered)</span>
        </div>
      </div>

      <ReactFlow
        nodes={nodes}
        edges={edges}
        nodeTypes={nodeTypes}
        onNodeClick={onNodeClick}
        fitView
        fitViewOptions={{ padding: 0.2 }}
        minZoom={0.3}
        maxZoom={1.5}
        proOptions={{ hideAttribution: true }}
      >
        <Background variant={BackgroundVariant.Dots} gap={20} size={1} color="#334155" />
        <Controls className="!bg-slate-900 !border-slate-700 !rounded-lg overflow-hidden" />
        <MiniMap
          nodeColor={(n) => {
            const mastery = (n.data as unknown as ConceptNodeData)?.mastery ?? 0.2;
            if (mastery >= 0.7) return "#10b981";
            if (mastery >= 0.4) return "#f59e0b";
            return "#ef4444";
          }}
          className="!bg-slate-900/90 !border-slate-800 !rounded-lg"
          maskColor="rgba(15, 23, 42, 0.7)"
        />
      </ReactFlow>
    </div>
  );
}
