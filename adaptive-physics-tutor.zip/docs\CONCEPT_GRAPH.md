# Concept Graph Taxonomy (Class 10 CBSE Electricity)

## 1. Directed Acyclic Graph (DAG) Structure
The chapter is modeled as a 15-node Directed Acyclic Graph stored in `data/concepts.json`. Edges signify strict prerequisite dependencies:

```mermaid
graph LR
    c1[Electric Charge & Quantization] --> c2[Electric Current & Circuits]
    c1 --> c3[Potential Difference & Voltage]
    c2 --> c4[Ohm's Law]
    c3 --> c4
    c4 --> c5[Resistance & Factors]
    c5 --> c6[Resistivity of Materials]
    c5 --> c7[Series Resistors Combination]
    c2 --> c8[Current & Voltage in Series]
    c7 --> c8
    c5 --> c9[Parallel Resistors Combination]
    c3 --> c10[Voltage & Current in Parallel]
    c9 --> c10
    c4 --> c11[Joule's Law of Heating]
    c11 --> c12[Practical Heating Applications]
    c4 --> c13[Electric Power Equations]
    c8 --> c13
    c10 --> c13
    c13 --> c14[Power-Resistance Relationship]
    c13 --> c15[Commercial Energy kWh]
```

---

## 2. Detailed Concept Catalog

| ID | Code | Concept Name | Key Formula / Principles | Direct Prerequisites |
| :--- | :--- | :--- | :--- | :--- |
| `c1_electric_charge` | `CHG` | **Electric Charge & Quantization** | $Q = ne$, $e \approx 1.6 \times 10^{-19}\text{ C}$, SI Unit: Coulomb ($C$) | *None (Root)* |
| `c2_electric_current` | `CUR` | **Electric Current & Circuits** | $I = Q / t$, SI Unit: Ampere ($A$), Direction of conventional current vs electron flow | `c1_electric_charge` |
| `c3_potential_diff` | `VOLT` | **Potential Difference & Voltage** | $V = W / Q$, SI Unit: Volt ($V$), 1 V = 1 Joule / 1 Coulomb | `c1_electric_charge` |
| `c4_ohms_law` | `OHM` | **Ohm's Law** | $V \propto I \implies V = IR$ at constant temperature | `c2_electric_current`, `c3_potential_diff` |
| `c5_resistance_factors` | `RES` | **Resistance & Factors Affecting It** | $R \propto l$, $R \propto 1/A$, nature of material, temperature | `c4_ohms_law` |
| `c6_resistivity` | `RHO` | **Resistivity of Materials** | $\rho = (R \cdot A) / l$, Unit: $\Omega\cdot\text{m}$, Intrinsic material constant | `c5_resistance_factors` |
| `c7_series_circuits` | `SER_R` | **Series Resistors Combination** | $R_s = R_1 + R_2 + \dots + R_n$ | `c5_resistance_factors` |
| `c8_series_current` | `SER_I` | **Current & Voltage in Series** | Identical current $I$ everywhere; $V = V_1 + V_2 + \dots$ | `c2_electric_current`, `c7_series_circuits` |
| `c9_parallel_circuits` | `PAR_R` | **Parallel Resistors Combination** | $1/R_p = 1/R_1 + 1/R_2 + \dots + 1/R_n$ | `c5_resistance_factors` |
| `c10_parallel_voltage` | `PAR_V` | **Voltage & Current in Parallel** | Identical voltage $V$ across all branches; $I = I_1 + I_2 + \dots$ | `c3_potential_diff`, `c9_parallel_circuits` |
| `c11_joules_heating` | `HEAT` | **Joule's Law of Heating** | $H = I^2 R t = V I t = \frac{V^2}{R} t$, Unit: Joules ($J$) | `c4_ohms_law` |
| `c12_heating_applications` | `FUSE` | **Practical Heating Applications** | Safety fuses (low melting point), tungsten bulb filament, nichrome appliances | `c11_joules_heating` |
| `c13_electric_power` | `PWR` | **Electric Power Equations** | $P = VI = I^2 R = \frac{V^2}{R}$, SI Unit: Watt ($W$) | `c4_ohms_law`, `c8_series_current`, `c10_parallel_voltage` |
| `c14_power_resistance_comp` | `PWR_R` | **Power-Resistance Relationship** | Series ($I$ constant): $P \propto R$; Parallel ($V$ constant): $P \propto 1/R$ | `c13_electric_power` |
| `c15_commercial_energy` | `KWH` | **Commercial Unit of Energy** | $1 \text{ kWh} = 1000\text{ W} \times 3600\text{ s} = 3.6 \times 10^6\text{ J}$ (1 Unit) | `c13_electric_power` |
