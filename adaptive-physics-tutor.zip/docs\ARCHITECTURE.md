# System Architecture

## 1. Overview
The **Adaptive Physics Tutor** follows a modern decoupled architecture built on Next.js (App Router), TypeScript, SQLite with Prisma ORM, React Flow (`@xyflow/react`), Framer Motion, and structured LLM integration.

```mermaid
flowchart TD
    subgraph Client ["Client (Browser)"]
        UI[Student Interface - app/page.tsx]
        CG[React Flow DAG Canvas]
        CSA[CardSplitAccordian Component]
        QC[Question Card & Pedagogical Reason]
        BKT_HUD[BKT Live Math Inspector]
    end

    subgraph API ["Next.js API Layer (/app/api)"]
        S_API[/api/state - Dynamic State Fetcher]
        A_API[/api/attempts - Answer & BKT Evaluator]
        R_API[/api/reset - Demo Prior Reset]
    end

    subgraph Deterministic ["Deterministic Engine (/lib)"]
        BKT[lib/bkt.ts - BKT Probability Engine]
        PROP[Prerequisite Attenuation Updater]
    end

    subgraph LLM ["LLM Guardrail Layer (/lib/llm.ts)"]
        WRAPPER[callStructuredLLM - JSON Schema Enforced]
        MISCON_DET[detectMisconception - Catalog Matcher]
    end

    subgraph Storage ["Database & Static Data"]
        PRISMA[(Prisma ORM)]
        SQLITE[(SQLite - dev.db)]
        CONCEPTS[(data/concepts.json)]
        MISCON_DB[(data/misconceptions.json)]
        QUESTIONS[(data/questions.json)]
    end

    UI --> CG & CSA & QC & BKT_HUD
    UI <--> S_API & A_API & R_API
    A_API --> BKT --> PROP
    A_API --> MISCON_DET --> WRAPPER
    BKT & PROP --> PRISMA --> SQLITE
    S_API --> PRISMA
    S_API & A_API --> CONCEPTS & MISCON_DB & QUESTIONS
```

---

## 2. Component Structure

### Frontend Layer
- **`app/page.tsx`**: Main student portal containing the split layout (Question Card on the left, Concept Visualizer on the right), stats header, and view toggles.
- **`components/ConceptGraph.tsx`**: Interactive Directed Acyclic Graph rendered with `@xyflow/react`, supporting zoom, pan, minimap, dynamic bezier edges, and real-time color transitions.
- **`components/ConceptNode.tsx`**: Custom node card component displaying concept code, title, mastery progress bar, and 3-tier status badges.
- **`components/QuestionCard.tsx`**: Question presentation card with the pedagogical transparency banner, interactive multiple-choice options, diagnostic reasoning textarea, and the BKT Math Inspector.
- **`components/ui/card-split-accordian.tsx`**: Animated split accordion built with `motion` and `react-use-measure` that displays concept formulas, prerequisites, and mastery meters with dynamic spring border morphing.

### Backend & API Layer
- **`app/api/state/route.ts`**: Serves the current student profile, enriched concepts with persisted mastery values, and diagnostic questions.
- **`app/api/attempts/route.ts`**: Validates student answers, triggers deterministic BKT updates, computes prerequisite propagation, invokes LLM misconception matching (when reasoning is provided on incorrect answers), and persists records to SQLite.
- **`app/api/reset/route.ts`**: Resets all concept masteries back to the default prior ($P(L_0) = 0.20$) for testing and replay.

### Logic & Data Layer
- **`lib/bkt.ts`**: Deterministic Bayesian Knowledge Tracing functions: posterior calculation, knowledge transition, clamping, and prerequisite attenuation.
- **`lib/bkt.test.ts`**: Unit test suite using Vitest verifying mathematical invariants.
- **`lib/llm.ts`**: Unified LLM client reading `GEMINI_API_KEY` from the environment, strictly guaranteeing JSON output, with a deterministic local fallback.
- **`lib/db.ts`**: PrismaClient singleton for Next.js hot-reloading.
- **`prisma/schema.prisma`**: Relational models for `Student`, `ConceptMastery`, and `QuestionAttempt`.
